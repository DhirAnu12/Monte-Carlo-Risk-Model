"""Market data: spot prices, historical volatility and correlations from yfinance.

What we compute from ~1 year of daily closing prices
----------------------------------------------------
* Log returns:   r_t = ln(P_t / P_{t-1}). Log returns add up over time, which
                 is what GBM assumes, and they are roughly normal for daily data.
* Volatility:    the standard deviation of daily log returns, scaled to a year
                 by sqrt(252). Variance grows linearly with time under GBM, so
                 standard deviation grows with the square root of time.
* Correlation:   Pearson correlation of the tickers' daily log returns, computed
                 only on days where every ticker traded.
* Spot:          the most recent close.

Prices are split/dividend adjusted (auto_adjust=True) so corporate actions don't
show up as fake jumps. Downloaded closes are cached to disk as CSV so repeated
runs are fast and work offline.
"""

from __future__ import annotations

import logging
import time
from collections.abc import Callable, Sequence
from dataclasses import dataclass
from pathlib import Path

import numpy as np
import pandas as pd

from simulate import TRADING_DAYS_PER_YEAR

log = logging.getLogger(__name__)

DEFAULT_CACHE_DIR = Path(__file__).parent / ".cache"
MIN_OBSERVATIONS = 20


@dataclass(frozen=True)
class MarketData:
    """Inputs needed by the simulator, aligned to `tickers` order."""

    tickers: list[str]
    spots: np.ndarray        # shape (n,)
    vols: np.ndarray         # shape (n,), annualized
    corr: np.ndarray         # shape (n, n)
    as_of: pd.Timestamp      # date of the latest close
    n_obs: int               # number of daily returns used

    def spot(self, ticker: str) -> float:
        return float(self.spots[self.tickers.index(ticker)])

    def vol(self, ticker: str) -> float:
        return float(self.vols[self.tickers.index(ticker)])


def compute_stats(closes: pd.DataFrame, tickers: Sequence[str] | None = None) -> MarketData:
    """Turn a DataFrame of daily closes (index = dates, columns = tickers) into
    spots, annualized vols and the log-return correlation matrix."""
    tickers = list(tickers) if tickers is not None else [str(c) for c in closes.columns]
    missing = [t for t in tickers if t not in closes.columns]
    if missing:
        raise ValueError(f"no price data for {missing}")
    px = closes[tickers].astype(float).sort_index()

    empty = [t for t in tickers if px[t].dropna().empty]
    if empty:
        raise ValueError(f"no price data for {empty}")
    if (px <= 0).any().any():
        raise ValueError("prices must be positive")

    # Joint returns: keep only days on which every ticker has a close.
    log_ret = np.log(px).diff().dropna(how="any")
    if len(log_ret) < MIN_OBSERVATIONS:
        raise ValueError(f"only {len(log_ret)} overlapping daily returns; need at least {MIN_OBSERVATIONS}")

    vols = log_ret.std(ddof=1).to_numpy() * np.sqrt(TRADING_DAYS_PER_YEAR)
    corr = np.atleast_2d(log_ret.corr().to_numpy())
    spots = np.array([px[t].dropna().iloc[-1] for t in tickers])
    return MarketData(
        tickers=tickers,
        spots=spots,
        vols=vols,
        corr=corr,
        as_of=pd.Timestamp(px.dropna(how="all").index[-1]),
        n_obs=len(log_ret),
    )


def _yfinance_download(tickers: Sequence[str], period: str) -> pd.DataFrame:
    """Download adjusted daily closes; returns a DataFrame with one column per ticker."""
    import yfinance as yf

    raw = yf.download(list(tickers), period=period, interval="1d", auto_adjust=True, progress=False)
    if raw is None or raw.empty:
        raise RuntimeError(f"yfinance returned no data for {list(tickers)}")
    closes = raw["Close"]
    if isinstance(closes, pd.Series):  # single ticker on some yfinance versions
        closes = closes.to_frame(name=tickers[0])
    closes.index = pd.DatetimeIndex(closes.index).tz_localize(None)
    return closes


def _cache_path(cache_dir: Path, tickers: Sequence[str], period: str) -> Path:
    return cache_dir / f"closes_{'_'.join(sorted(tickers))}_{period}.csv"


def load_closes(
    tickers: Sequence[str],
    period: str = "1y",
    cache_dir: str | Path = DEFAULT_CACHE_DIR,
    max_age_hours: float = 12.0,
    refresh: bool = False,
    downloader: Callable[[Sequence[str], str], pd.DataFrame] = _yfinance_download,
) -> pd.DataFrame:
    """Daily closes for `tickers`, using an on-disk cache.

    The cache is used if it is younger than `max_age_hours` (unless `refresh`).
    If a download fails and any cached copy exists, the stale copy is used with
    a warning rather than failing the run.
    """
    cache_dir = Path(cache_dir)
    path = _cache_path(cache_dir, tickers, period)
    if path.exists() and not refresh:
        age_h = (time.time() - path.stat().st_mtime) / 3600
        if age_h < max_age_hours:
            log.info("using cached prices %s (%.1fh old)", path.name, age_h)
            return pd.read_csv(path, index_col=0, parse_dates=True)

    try:
        closes = downloader(tickers, period)
    except Exception as e:
        if path.exists():
            log.warning("download failed (%s); using stale cache %s", e, path.name)
            return pd.read_csv(path, index_col=0, parse_dates=True)
        raise

    cache_dir.mkdir(parents=True, exist_ok=True)
    closes.to_csv(path)
    return closes


def get_market_data(
    tickers: Sequence[str],
    period: str = "1y",
    cache_dir: str | Path = DEFAULT_CACHE_DIR,
    max_age_hours: float = 12.0,
    refresh: bool = False,
    downloader: Callable[[Sequence[str], str], pd.DataFrame] = _yfinance_download,
) -> MarketData:
    """Fetch (or load cached) closes and compute spots, vols and correlations."""
    tickers = list(tickers)
    closes = load_closes(tickers, period, cache_dir, max_age_hours, refresh, downloader)
    return compute_stats(closes, tickers)
