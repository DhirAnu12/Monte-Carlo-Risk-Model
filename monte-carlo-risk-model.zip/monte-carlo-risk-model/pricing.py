"""Black-Scholes pricing and Greeks for European options.

All functions are vectorized: any argument may be a scalar or a NumPy array,
and inputs broadcast against each other. This matters because the risk engine
reprices each option on every simulated path at once (10,000+ spot values).

Conventions
-----------
S      spot price of the underlying
K      strike price
T      time to expiry in years
r      continuously compounded risk-free rate (annual)
sigma  annualized volatility of the underlying's log returns
Prices are per share (multiply by the contract multiplier elsewhere).
"""

from __future__ import annotations

from typing import Literal

import numpy as np
from numpy.typing import ArrayLike, NDArray
from scipy.stats import norm

OptionType = Literal["call", "put"]

# Below this time to expiry (in years, ~30 seconds) we treat the option as expired.
_T_EPS = 1e-9


def _validate_type(option_type: str) -> str:
    t = option_type.lower()
    if t not in ("call", "put"):
        raise ValueError(f"option_type must be 'call' or 'put', got {option_type!r}")
    return t


def intrinsic_value(S: ArrayLike, K: ArrayLike, option_type: OptionType) -> NDArray[np.float64]:
    """Payoff if exercised right now: max(S-K, 0) for a call, max(K-S, 0) for a put."""
    t = _validate_type(option_type)
    S = np.asarray(S, dtype=float)
    K = np.asarray(K, dtype=float)
    return np.maximum(S - K, 0.0) if t == "call" else np.maximum(K - S, 0.0)


def _d1_d2(S, K, T, r, sigma):
    """The two standardized distances used by Black-Scholes.

    d1 = [ln(S/K) + (r + sigma^2/2) T] / (sigma sqrt(T))
    d2 = d1 - sigma sqrt(T)

    In plain terms: d2 measures how many standard deviations the (risk-neutral)
    expected log price at expiry sits above the strike. N(d2) is then the
    risk-neutral probability the option finishes in the money. d1 is the same
    quantity under a measure that uses the stock as numeraire; N(d1) is the
    call's delta.
    """
    sqrt_T = np.sqrt(T)
    vol_sqrt_T = sigma * sqrt_T
    d1 = (np.log(S / K) + (r + 0.5 * sigma**2) * T) / vol_sqrt_T
    d2 = d1 - vol_sqrt_T
    return d1, d2


def bs_price(
    S: ArrayLike,
    K: ArrayLike,
    T: ArrayLike,
    r: ArrayLike,
    sigma: ArrayLike,
    option_type: OptionType,
) -> NDArray[np.float64]:
    """Black-Scholes price of a European call or put.

    Call = S N(d1) - K e^{-rT} N(d2)
    Put  = K e^{-rT} N(-d2) - S N(-d1)

    Read the call formula as: "what you expect to receive (the stock, weighted
    by how likely you are to exercise) minus what you expect to pay (the
    strike, discounted to today, weighted by the probability of exercise)".

    Degenerate cases are handled explicitly:
    * T <= 0: the option has expired, so its value is the intrinsic payoff.
    * sigma == 0: the future is deterministic; the value is the discounted
      payoff on the forward price S e^{rT}.
    """
    t = _validate_type(option_type)
    S, K, T, r, sigma = np.broadcast_arrays(*(np.asarray(x, dtype=float) for x in (S, K, T, r, sigma)))

    out = np.empty(S.shape, dtype=float)
    expired = T <= _T_EPS
    zero_vol = (~expired) & (sigma <= 0.0)
    live = ~(expired | zero_vol)

    out[expired] = intrinsic_value(S[expired], K[expired], t)

    if zero_vol.any():
        disc = np.exp(-r[zero_vol] * T[zero_vol])
        fwd = S[zero_vol] / disc
        out[zero_vol] = disc * intrinsic_value(fwd, K[zero_vol], t)

    if live.any():
        s, k, tt, rr, v = S[live], K[live], T[live], r[live], sigma[live]
        d1, d2 = _d1_d2(s, k, tt, rr, v)
        disc_k = k * np.exp(-rr * tt)
        if t == "call":
            out[live] = s * norm.cdf(d1) - disc_k * norm.cdf(d2)
        else:
            out[live] = disc_k * norm.cdf(-d2) - s * norm.cdf(-d1)

    return out if out.ndim else out[()]


def bs_greeks(
    S: ArrayLike,
    K: ArrayLike,
    T: ArrayLike,
    r: ArrayLike,
    sigma: ArrayLike,
    option_type: OptionType,
) -> dict[str, NDArray[np.float64]]:
    """Black-Scholes sensitivities ("Greeks") of a European option, per share.

    delta  dPrice/dS            how much the option moves per $1 move in the stock
                                (call: N(d1), put: N(d1) - 1)
    gamma  d2Price/dS2          how fast delta changes per $1 move; same for calls
                                and puts: n(d1) / (S sigma sqrt(T))
    vega   dPrice/dsigma        price change per 1.00 (i.e. 100 vol points) change
                                in volatility: S n(d1) sqrt(T). Divide by 100 for
                                "per vol point".
    theta  dPrice/dt            price change per year of passing time (usually
                                negative: options lose value as expiry nears).
                                Divide by 365 for "per calendar day".
    rho    dPrice/dr            price change per 1.00 change in the rate:
                                call K T e^{-rT} N(d2), put -K T e^{-rT} N(-d2)

    n(.) is the standard normal density and N(.) its cumulative distribution.
    For expired options (T <= 0) all Greeks are zero except delta, which is the
    exercise indicator (1/-1 if in the money, 0 otherwise).
    """
    t = _validate_type(option_type)
    S, K, T, r, sigma = np.broadcast_arrays(*(np.asarray(x, dtype=float) for x in (S, K, T, r, sigma)))

    live = (T > _T_EPS) & (sigma > 0.0)
    greeks = {name: np.zeros(S.shape) for name in ("delta", "gamma", "vega", "theta", "rho")}

    # Expired / zero-vol: delta is the exercise indicator on the (forward) price.
    dead = ~live
    if dead.any():
        fwd = S[dead] * np.exp(r[dead] * np.maximum(T[dead], 0.0))
        if t == "call":
            greeks["delta"][dead] = (fwd > K[dead]).astype(float)
        else:
            greeks["delta"][dead] = -(fwd < K[dead]).astype(float)

    if live.any():
        s, k, tt, rr, v = S[live], K[live], T[live], r[live], sigma[live]
        d1, d2 = _d1_d2(s, k, tt, rr, v)
        sqrt_T = np.sqrt(tt)
        pdf_d1 = norm.pdf(d1)
        disc_k = k * np.exp(-rr * tt)

        greeks["gamma"][live] = pdf_d1 / (s * v * sqrt_T)
        greeks["vega"][live] = s * pdf_d1 * sqrt_T
        decay = -s * pdf_d1 * v / (2.0 * sqrt_T)  # time decay common to calls and puts
        if t == "call":
            greeks["delta"][live] = norm.cdf(d1)
            greeks["theta"][live] = decay - rr * disc_k * norm.cdf(d2)
            greeks["rho"][live] = tt * disc_k * norm.cdf(d2)
        else:
            greeks["delta"][live] = norm.cdf(d1) - 1.0
            greeks["theta"][live] = decay + rr * disc_k * norm.cdf(-d2)
            greeks["rho"][live] = -tt * disc_k * norm.cdf(-d2)

    return {name: (g if g.ndim else g[()]) for name, g in greeks.items()}
