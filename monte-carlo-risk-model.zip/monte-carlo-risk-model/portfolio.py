"""Portfolio definition: load option positions from CSV.

CSV columns
-----------
ticker       underlying symbol, e.g. AAPL
type         "call" or "put"
strike       strike price per share
expiry       expiry date, YYYY-MM-DD
quantity     number of contracts; negative means short (you sold the option)
entry_price  premium per share paid (long) or received (short)
iv           optional: implied vol to price this contract with, as a decimal
             (0.25 = 25%). Leave blank or omit the column to use the market
             implied vol from the option chain.

Every contract covers CONTRACT_MULTIPLIER (100) shares, so a position's dollar
value is price-per-share x quantity x 100.
"""

from __future__ import annotations

import csv
from dataclasses import dataclass
from datetime import date
from pathlib import Path

CONTRACT_MULTIPLIER = 100
REQUIRED_COLUMNS = ("ticker", "type", "strike", "expiry", "quantity", "entry_price")
OPTIONAL_COLUMNS = ("iv",)
MAX_IV_OVERRIDE = 5.0  # 500%; anything larger is almost certainly a percent typed as a whole number


@dataclass(frozen=True)
class Position:
    """One option position.

    P&L convention: a position's P&L is (value_now - entry_price) x quantity x 100.
    For a short position (quantity < 0), a fall in the option's value is a gain.
    """

    ticker: str
    option_type: str
    strike: float
    expiry: date
    quantity: int
    entry_price: float
    iv: float | None = None  # manual implied-vol override; None = use the option chain

    @property
    def is_long(self) -> bool:
        return self.quantity > 0

    @property
    def cost_basis(self) -> float:
        """Signed dollars paid at entry (negative for shorts: you received premium)."""
        return self.entry_price * self.quantity * CONTRACT_MULTIPLIER

    def label(self) -> str:
        side = "Long" if self.is_long else "Short"
        return f"{side} {abs(self.quantity)} {self.ticker} {self.strike:g}{self.option_type[0].upper()} {self.expiry:%Y-%m-%d}"


class PortfolioError(ValueError):
    """Raised for malformed position files."""


def _parse_row(row: dict[str, str], line: int) -> Position:
    try:
        ticker = row["ticker"].strip().upper()
        option_type = row["type"].strip().lower()
        strike = float(row["strike"])
        expiry = date.fromisoformat(row["expiry"].strip())
        qty_f = float(row["quantity"])
        entry_price = float(row["entry_price"])
        iv_raw = (row.get("iv") or "").strip()
        iv = float(iv_raw) if iv_raw else None
    except (KeyError, ValueError, AttributeError) as e:
        raise PortfolioError(f"line {line}: could not parse row {row!r}: {e}") from e

    if not ticker:
        raise PortfolioError(f"line {line}: empty ticker")
    if option_type not in ("call", "put"):
        raise PortfolioError(f"line {line}: type must be 'call' or 'put', got {row['type']!r}")
    if strike <= 0:
        raise PortfolioError(f"line {line}: strike must be positive, got {strike}")
    if qty_f == 0 or qty_f != int(qty_f):
        raise PortfolioError(f"line {line}: quantity must be a non-zero whole number, got {row['quantity']!r}")
    if entry_price < 0:
        raise PortfolioError(f"line {line}: entry_price cannot be negative, got {entry_price}")

    if iv is not None and not 0 < iv <= MAX_IV_OVERRIDE:
        raise PortfolioError(
            f"line {line}: iv must be a decimal in (0, {MAX_IV_OVERRIDE:g}] (e.g. 0.25 for 25%), got {iv_raw!r}"
        )

    return Position(ticker, option_type, strike, expiry, int(qty_f), entry_price, iv)


def load_positions(path: str | Path) -> list[Position]:
    """Read and validate a positions CSV. Raises PortfolioError on bad input."""
    path = Path(path)
    with path.open(newline="") as f:
        reader = csv.DictReader(f)
        header = [c.strip().lower() for c in (reader.fieldnames or [])]
        missing = [c for c in REQUIRED_COLUMNS if c not in header]
        if missing:
            raise PortfolioError(f"{path}: missing columns {missing}")
        reader.fieldnames = header
        positions = [
            _parse_row(row, i)
            for i, row in enumerate(reader, start=2)
            if any((v or "").strip() for v in row.values())  # skip blank lines
        ]
    if not positions:
        raise PortfolioError(f"{path}: no positions found")
    return positions


def tickers_of(positions: list[Position]) -> list[str]:
    """Unique underlyings, in order of first appearance."""
    return list(dict.fromkeys(p.ticker for p in positions))
