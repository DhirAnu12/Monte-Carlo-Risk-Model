# Monte Carlo Risk Model for an Options Portfolio

Simulates thousands of correlated future price paths for the underlyings in an
options book, reprices every option on every path at a chosen horizon, and
reports the resulting P&L distribution: mean, median, probability of profit,
95%/99% VaR and CVaR, max loss and max gain. It also saves a P&L histogram and
fan charts of the simulated prices.

## Quick start

```bash
python3 -m venv .venv
.venv/bin/pip install -r requirements.txt
.venv/bin/python main.py                       # sample portfolio, 10k paths, 21 trading days
.venv/bin/pytest                               # run the test suite
```

### CLI options

| Flag | Default | Meaning |
|---|---|---|
| `--positions` | `positions.csv` | Positions file |
| `--paths` | `10000` | Number of simulated paths |
| `--horizon` | `21` | Horizon in trading days (21 ≈ 1 month) |
| `--rate` | `0.04` | Risk-free rate (annual, continuously compounded) |
| `--drift TICKER=MU` | the rate | Per-ticker annual drift override (repeatable) |
| `--seed` | `42` | RNG seed; same seed ⇒ same results |
| `--period` | `1y` | History window for volatility and correlation |
| `--valuation-date` | last close | Date the portfolio is valued from |
| `--refresh` | off | Ignore cached prices and option chains, and re-download |
| `--no-iv` | off | Price options at historical vol instead of market implied vol (`iv` overrides still apply) |
| `--cache-dir` | `.cache/` | Where downloaded prices and option chains are cached |
| `--out` | `output/` | Where charts are written |
| `--no-plots` | off | Skip charts |

Example with a bullish view on AAPL over three months:

```bash
.venv/bin/python main.py --horizon 63 --drift AAPL=0.12 --paths 50000
```

## Positions file

```csv
ticker,type,strike,expiry,quantity,entry_price,iv
AAPL,call,370,2027-01-15,10,8.40,
AAPL,put,330,2026-12-04,-5,2.10,0.28
```

`quantity` is in contracts, and a negative quantity means short. `entry_price` is the premium per
share. Each contract covers 100 shares.

`iv` is optional. Leave it blank, or leave the column out entirely, to use the
market implied vol. Put a decimal in it (`0.28` = 28%) to price that contract
at your own vol instead. An override always wins: no download happens for that
contract.

## Which volatility is used where

| Job | Volatility |
|---|---|
| Simulating stock paths | **Historical** vol and correlation (1y of daily log returns) |
| Pricing an option today and at the horizon | That contract's **implied** vol |

For each position, the pricing vol comes from the first of these that applies:

1. The `iv` override in `positions.csv`.
2. The `impliedVolatility` that Yahoo reports for that exact strike, expiry and
   call/put, if the quote looks sane.
3. The ticker's historical vol. This is a fallback, and it prints a warning
   that names the position and gives the reason.

A quote counts as broken when:
- its implied vol is missing, below 1% (Yahoo uses values like 0.00001 as
  placeholders) or above 500%; or
- there is no two-sided market: the bid or ask is missing or zero, or the ask is
  below the bid.

The strike not being listed, the expiry not being listed, or the download
failing also triggers the fallback. Option chains are cached per ticker and
expiry in `.cache/`, refreshed after 12h. If the download fails, a stale cache
is used.

The positions table shows the historical vol, the implied vol, and which one the
contract was priced at.

## Assumptions

These are deliberate simplifications. Results are only as good as they are.

- **European options.** No early exercise. The model prices American-style
  single-stock options as if they were European. This understates value mainly
  for deep in-the-money puts and for calls just before an ex-dividend date.
- **100× contract multiplier** for every position.
- **Two volatilities, both held constant.**
  - Stock paths use each underlying's historical vol.
  - Each option is priced at its own implied vol, both today and at the horizon.
    That vol is **frozen**: a crash does not raise implied vols (no sticky-delta
    or sticky-strike dynamics, and no vol-of-vol). Real portfolios with short
    options usually lose more in a crash than this shows.
  - The smile is captured only as a snapshot. Each contract keeps today's implied
    vol for its strike even though, at the horizon, the stock has moved and the
    strike sits at a different point on the smile.
  - Implied vol is usually above historical vol, so the paths are typically
    calmer than the option prices assume. That mismatch shows up as a drag in
    the "vs. today's value" P&L of long options. It is a known effect, not a bug.
- **Yahoo's implied vols are used as reported.**
  - Yahoo computes them with its own rate, dividend and pricing conventions. Our
    Black-Scholes, with `--rate` and no dividends, may not reproduce the market
    price exactly at that vol.
  - On the sample book in November 2026, Yahoo's vols were 1–3.5 vol points
    away from the vols that reproduce the bid/ask mid. That moved model prices
    by up to about 10% (MSFT 520C: 44.88 model vs 40.75 mid). To pin a contract
    to a vol you trust, use the `iv` column.
- **Constant risk-free rate.** It is used for discounting in Black-Scholes and
  as the default drift.
- **No dividends.** Black-Scholes is used without a dividend yield (SPY, AAPL and MSFT pay
  small ones). Historical prices are dividend-adjusted.
- **Geometric Brownian motion.**
  - Log returns are normal, with no jumps or fat tails beyond what correlation
    produces.
  - The correlation is constant, taken from the sample correlation matrix of
    daily log returns.
- **Default drift = risk-free rate** (risk-neutral paths). For a
  real-world view, override it per ticker with `--drift`.
- **Time conventions.**
  - Simulation steps are trading days (dt = 1/252). The horizon date is
    valuation date + N business days. Weekends are skipped, but exchange
    holidays are ignored.
  - Time to expiry for Black-Scholes is calendar days / 365.
- **Expiry within the horizon.**
  - An option that expires on or before the horizon is cash-settled at its
    intrinsic value.
  - That value uses the simulated price **on its expiry date**, not at the
    horizon.
  - The cash is held at zero interest until the horizon. There is no
    assignment into stock and no reinvestment.
- **No transaction costs, bid/ask, margin or liquidity effects.** All valuation is
  mark-to-model.

## How it works

| Module | Role |
|---|---|
| `portfolio.py` | Loads and validates `positions.csv` into `Position` objects. |
| `implied_vol.py` | Looks up each contract's implied vol in the yfinance option chain. Checks the quote is sane, caches chains, and applies `iv` overrides and the historical-vol fallback. |
| `market_data.py` | Downloads 1y of adjusted daily closes with yfinance. Computes spot, annualized vol (σ = std(log returns) × √252) and the correlation matrix. Caches the closes in `.cache/`, refreshes them after 12h, and falls back to a stale cache when offline. |
| `simulate.py` | Correlated GBM paths, fully vectorized. Draws independent normals, correlates them with the Cholesky factor L of the correlation matrix (Z = Lε), and accumulates log returns `(μ − σ²/2)dt + σ√dt·Z`. Output has shape `(paths, days+1, tickers)`. |
| `pricing.py` | Vectorized Black-Scholes price and Greeks (delta, gamma, vega, theta, rho). |
| `risk.py` | Reprices each position on each path at the horizon, then builds the P&L and risk metrics. |
| `plots.py` | P&L histogram with VaR and mean lines, and a fan chart per ticker. |
| `main.py` | CLI. Prints the tables and saves the charts. |

### Two P&L views

The summary reports P&L two ways:

- **vs. entry price:** this is what you'll have made or lost on the trades by
  the horizon. It includes any gain or loss already sitting in the book today.
- **vs. today's model value:** this isolates the risk *from now to the horizon*.
  It is the better number for "how much could I lose this month?".

Both views have the same shape. They differ only by today's unrealized P&L.

### Risk measures

- **VaR 95%:** the loss exceeded on only 5% of paths.
- **CVaR 95%** (Expected Shortfall): the average loss on those worst 5% of
  paths. It is always ≥ VaR, and it captures how bad the tail is.
- VaR and CVaR are quoted as positive dollar losses. Max loss and max gain are
  the signed worst and best P&L.

## Tests

`pytest` runs about 200 tests. All are offline: `tests/conftest.py` blocks network access.

- **Black-Scholes known values:**
  - Hull's textbook example: S=42, K=40, r=10%, σ=20%, T=0.5 gives C=4.76 and P=0.81.
  - The standard at-the-money (ATM) reference values, including its Greeks.
- **Put-call parity:** `C − P = S − Ke^{−rT}` across a grid of inputs and
  1,000 random cases.
- **Greeks vs. finite differences.**
- **MC convergence:** the discounted mean payoff of a European call from the
  simulator lands within 3 standard errors of Black-Scholes at 2k and 200k paths.
- **The simulator recovers its inputs:** the input correlation, vol and drift
  are recovered from the paths, and the same seed gives the same paths.
- **Revaluation:** hand-computed P&L, settlement on the expiry date, the live
  Black-Scholes branch, and VaR/CVaR on known distributions.
- **Market-data statistics and caching:** use synthetic prices, with no network.
- **Implied vol:**
  - The exact contract (type and strike) is looked up in the chain.
  - Each fallback case: zero or placeholder IV, no bid, missing ask, crossed
    quote, unknown strike, unlisted expiry, download failure.
  - Overrides win over broken quotes and skip the download.
  - `--no-iv` mode, chain caching, and the stale-cache fallback.
  - Parsing and validation of the optional `iv` column.
- **End-to-end CLI runs:** both vols are shown, there is exactly one warning
  naming the fallback position, the override column works, and `--no-iv` works.
