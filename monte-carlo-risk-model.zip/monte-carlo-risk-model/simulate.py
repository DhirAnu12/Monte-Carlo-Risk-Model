"""Correlated geometric Brownian motion (GBM) path simulation.

The model
---------
Each stock follows GBM: over a small time step dt its log price changes by

    ln(S_{t+dt} / S_t) = (mu - sigma^2 / 2) dt + sigma sqrt(dt) Z

where Z is a standard normal shock. The "- sigma^2/2" term (the Ito correction)
ensures the *average* price grows at rate mu: E[S_T] = S_0 e^{mu T}. Without it
the median would grow at mu and the mean would grow faster.

Correlation
-----------
Stocks don't move independently. To make the shocks Z for different tickers
correlated with correlation matrix C, we draw independent normals eps and set
Z = L eps, where L is the Cholesky factor of C (C = L L^T, L lower-triangular).
Then Cov(Z) = L Cov(eps) L^T = L I L^T = C. Intuitively, L "mixes" independent
noise so that, e.g., the second ticker's shock is part first-ticker shock and
part its own independent noise.

Everything is vectorized: one call to the random number generator produces all
shocks for all paths, steps and tickers, and cumulative sums over the time axis
turn per-step log returns into price paths.
"""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from dataclasses import dataclass

import numpy as np
from numpy.typing import ArrayLike, NDArray

TRADING_DAYS_PER_YEAR = 252


@dataclass(frozen=True)
class SimulationResult:
    """Simulated price paths.

    paths has shape (n_paths, n_steps + 1, n_tickers); paths[:, 0, :] is the
    starting spot and paths[:, -1, :] the price at the horizon.
    """

    tickers: list[str]
    paths: NDArray[np.float64]
    dt: float

    @property
    def terminal(self) -> NDArray[np.float64]:
        """Prices at the horizon, shape (n_paths, n_tickers)."""
        return self.paths[:, -1, :]

    def ticker_paths(self, ticker: str) -> NDArray[np.float64]:
        """All paths for one ticker, shape (n_paths, n_steps + 1)."""
        return self.paths[:, :, self.tickers.index(ticker)]


def safe_cholesky(corr: ArrayLike) -> NDArray[np.float64]:
    """Cholesky factor of a correlation matrix, repairing it if necessary.

    Sample correlation matrices can be very slightly non-positive-definite
    because of rounding (or if tickers are almost perfectly correlated). In that
    case we clip negative eigenvalues to a tiny positive number, rebuild the
    matrix, and rescale it so the diagonal is exactly 1 again.
    """
    C = np.asarray(corr, dtype=float)
    if C.ndim != 2 or C.shape[0] != C.shape[1]:
        raise ValueError(f"correlation matrix must be square, got shape {C.shape}")
    if not np.allclose(C, C.T, atol=1e-10):
        raise ValueError("correlation matrix must be symmetric")
    try:
        return np.linalg.cholesky(C)
    except np.linalg.LinAlgError:
        w, V = np.linalg.eigh(C)
        C = (V * np.maximum(w, 1e-10)) @ V.T
        d = np.sqrt(np.diag(C))
        C = C / np.outer(d, d)
        return np.linalg.cholesky(C)


def simulate_gbm(
    tickers: Sequence[str],
    spots: ArrayLike,
    vols: ArrayLike,
    corr: ArrayLike,
    horizon_days: int,
    n_paths: int = 10_000,
    rate: float = 0.04,
    drift: Mapping[str, float] | None = None,
    seed: int | None = None,
    antithetic: bool = False,
) -> SimulationResult:
    """Simulate correlated GBM price paths with daily steps.

    Parameters
    ----------
    tickers       names, in the same order as spots/vols/corr rows.
    spots         starting prices S_0.
    vols          annualized volatilities sigma.
    corr          correlation matrix of daily log returns.
    horizon_days  number of trading-day steps to simulate (dt = 1/252 year).
    n_paths       number of independent scenarios.
    rate          risk-free rate, used as the drift mu for any ticker not in
                  `drift`. Using the risk-free rate gives "risk-neutral" paths;
                  overriding it lets you express a real-world view.
    drift         optional {ticker: mu} overrides (annualized).
    seed          RNG seed; the same seed always produces the same paths.
    antithetic    if True, the second half of the paths uses the negated shocks
                  of the first half. This keeps the mean of the shocks at
                  exactly zero and reduces Monte Carlo noise; n_paths must be even.
    """
    tickers = list(tickers)
    n = len(tickers)
    S0 = np.asarray(spots, dtype=float).reshape(n)
    sigma = np.asarray(vols, dtype=float).reshape(n)
    if horizon_days < 1:
        raise ValueError("horizon_days must be >= 1")
    if n_paths < 1:
        raise ValueError("n_paths must be >= 1")
    if np.any(S0 <= 0) or np.any(sigma < 0):
        raise ValueError("spots must be positive and vols non-negative")
    drift = dict(drift or {})
    unknown = set(drift) - set(tickers)
    if unknown:
        raise ValueError(f"drift given for unknown tickers: {sorted(unknown)}")
    mu = np.array([drift.get(t, rate) for t in tickers], dtype=float)

    L = safe_cholesky(corr)
    if L.shape != (n, n):
        raise ValueError(f"correlation matrix shape {L.shape} does not match {n} tickers")

    dt = 1.0 / TRADING_DAYS_PER_YEAR
    rng = np.random.default_rng(seed)

    # Independent standard normals: (paths, steps, tickers)
    if antithetic:
        if n_paths % 2:
            raise ValueError("n_paths must be even when antithetic=True")
        half = rng.standard_normal((n_paths // 2, horizon_days, n))
        eps = np.concatenate([half, -half], axis=0)
    else:
        eps = rng.standard_normal((n_paths, horizon_days, n))

    # Correlate across the ticker axis: Z[p, t, :] = L @ eps[p, t, :]
    Z = eps @ L.T

    # Per-step log returns, then cumulative log return along the time axis.
    log_ret = (mu - 0.5 * sigma**2) * dt + sigma * np.sqrt(dt) * Z
    cum = np.cumsum(log_ret, axis=1)

    paths = np.empty((n_paths, horizon_days + 1, n))
    paths[:, 0, :] = S0
    paths[:, 1:, :] = S0 * np.exp(cum)
    return SimulationResult(tickers=tickers, paths=paths, dt=dt)
