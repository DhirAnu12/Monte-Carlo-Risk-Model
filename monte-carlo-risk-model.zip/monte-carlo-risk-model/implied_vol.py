"""Implied volatility per option contract, from the yfinance option chain.

Why implied vol?
----------------
Historical vol says how jumpy a stock *was* over the past year. Implied vol is
the volatility the options market is *currently charging for*. It is the number
that, plugged into Black-Scholes, reproduces the option's market price. Each
strike and expiry has its own implied vol (the "smile" or "skew"), so pricing each
contract at its own implied vol makes today's model values line up with the
market instead of with a backward-looking average.

The simulation of stock paths still uses historical vol and correlation; only
option *pricing* switches to implied vol.

Where each contract's pricing vol comes from (first match wins)
---------------------------------------------------------------
1. "override": an `iv` value in positions.csv.
2. "chain":    the contract's impliedVolatility from yfinance, if the quote
               looks sane (see `quote_problem`).
3. "historical": fallback, with a reason recorded so the caller can warn.

Downloaded chains are cached to disk per (ticker, expiry), like price data.
"""

from __future__ import annotations

import logging
import math
import time
from collections.abc import Callable, Mapping, Sequence
from dataclasses import dataclass
from datetime import date
from pathlib import Path

import pandas as pd

from market_data import DEFAULT_CACHE_DIR
from portfolio import Position

log = logging.getLogger(__name__)

CHAIN_COLUMNS = ["type", "strike", "bid", "ask", "impliedVolatility"]

# Yahoo reports placeholder IVs like 1e-5 or 0.0 for stale or unquoted contracts,
# and occasionally absurd values for illiquid ones. Outside this band we treat
# the IV as broken.
MIN_SANE_IV = 0.01   # 1%
MAX_SANE_IV = 5.0    # 500%

STRIKE_TOL = 1e-6

ChainDownloader = Callable[[str, date], pd.DataFrame]


class ExpiryNotListed(LookupError):
    """The requested expiry is not in the ticker's list of option expirations."""


@dataclass(frozen=True)
class VolChoice:
    """The volatility used to price one position, and where it came from."""

    position: Position
    hist_vol: float
    implied_vol: float | None   # override or chain IV, if one was obtained (even if rejected)
    pricing_vol: float          # what Black-Scholes will use
    source: str                 # "override" | "chain" | "historical"
    warning: str | None = None  # why we fell back, if we did


# --- Download + cache ----------------------------------------------------------

def _yfinance_chain(ticker: str, expiry: date) -> pd.DataFrame:
    """Calls and puts for one expiry, as a DataFrame with CHAIN_COLUMNS."""
    import yfinance as yf

    t = yf.Ticker(ticker)
    exp = expiry.isoformat()
    if exp not in (t.options or ()):
        raise ExpiryNotListed(f"{ticker} has no listed options expiring {exp}")
    chain = t.option_chain(exp)
    frames = []
    for kind, df in (("call", chain.calls), ("put", chain.puts)):
        df = df.reindex(columns=["strike", "bid", "ask", "impliedVolatility"]).copy()
        df.insert(0, "type", kind)
        frames.append(df)
    return pd.concat(frames, ignore_index=True)


def _chain_cache_path(cache_dir: Path, ticker: str, expiry: date) -> Path:
    return cache_dir / f"chain_{ticker}_{expiry.isoformat()}.csv"


def load_chain(
    ticker: str,
    expiry: date,
    cache_dir: str | Path = DEFAULT_CACHE_DIR,
    max_age_hours: float = 12.0,
    refresh: bool = False,
    downloader: ChainDownloader | None = None,
) -> pd.DataFrame:
    """Option chain for one ticker and expiry, using an on-disk cache.

    Same policy as price data: use a fresh cache if one exists, otherwise
    download, and if the download fails fall back to a stale cache. An
    ExpiryNotListed error is never masked by a stale cache.
    """
    downloader = downloader or _yfinance_chain
    cache_dir = Path(cache_dir)
    path = _chain_cache_path(cache_dir, ticker, expiry)
    if path.exists() and not refresh:
        age_h = (time.time() - path.stat().st_mtime) / 3600
        if age_h < max_age_hours:
            return pd.read_csv(path)

    try:
        chain = downloader(ticker, expiry)
    except ExpiryNotListed:
        raise
    except Exception as e:
        if path.exists():
            log.warning("option chain download failed for %s %s (%s); using stale cache", ticker, expiry, e)
            return pd.read_csv(path)
        raise

    chain = chain.reindex(columns=CHAIN_COLUMNS)
    cache_dir.mkdir(parents=True, exist_ok=True)
    chain.to_csv(path, index=False)
    return chain


# --- Quote checks -----------------------------------------------------------------

def _num(x) -> float:
    try:
        return float(x)
    except (TypeError, ValueError):
        return math.nan


def quote_problem(iv, bid, ask) -> str | None:
    """Return a short reason if a quote looks broken, else None.

    Broken means: IV missing, zero/near-zero or absurdly high; or no two-sided
    market (bid or ask missing or zero, or ask below bid). A one-sided or empty
    market means Yahoo's IV was backed out of a stale last-trade price, so it
    can't be trusted.
    """
    iv, bid, ask = _num(iv), _num(bid), _num(ask)
    if math.isnan(iv):
        return "implied vol missing"
    if iv < MIN_SANE_IV:
        return f"implied vol {iv:.4%} is effectively zero"
    if iv > MAX_SANE_IV:
        return f"implied vol {iv:.0%} is implausibly high"
    if math.isnan(bid) or math.isnan(ask) or bid <= 0 or ask <= 0:
        return f"no two-sided quote (bid {bid:g}, ask {ask:g})"
    if ask < bid:
        return f"crossed quote (bid {bid:g} > ask {ask:g})"
    return None


def find_contract(chain: pd.DataFrame, option_type: str, strike: float) -> pd.Series | None:
    """The chain row for this exact type and strike, or None."""
    rows = chain[(chain["type"] == option_type) & ((chain["strike"].astype(float) - strike).abs() < STRIKE_TOL)]
    return None if rows.empty else rows.iloc[0]


# --- Resolution -----------------------------------------------------------------------

def resolve_pricing_vols(
    positions: Sequence[Position],
    hist_vols: Mapping[str, float],
    valuation_date: date,
    use_market_iv: bool = True,
    cache_dir: str | Path = DEFAULT_CACHE_DIR,
    max_age_hours: float = 12.0,
    refresh: bool = False,
    downloader: ChainDownloader | None = None,
) -> list[VolChoice]:
    """Pick the Black-Scholes volatility for every position.

    Each (ticker, expiry) chain is fetched at most once per call. Positions with
    an `iv` override never trigger a download. If `use_market_iv` is False,
    every position without an override uses historical vol (no warning).
    """
    chains: dict[tuple[str, date], pd.DataFrame | Exception] = {}
    out: list[VolChoice] = []

    for p in positions:
        hv = float(hist_vols[p.ticker])

        if p.iv is not None:
            out.append(VolChoice(p, hv, p.iv, p.iv, "override"))
            continue
        if not use_market_iv:
            out.append(VolChoice(p, hv, None, hv, "historical"))
            continue
        if p.expiry < valuation_date:
            # Already settled, so it is valued at intrinsic value and vol is irrelevant.
            # main.py warns about expired positions separately.
            out.append(VolChoice(p, hv, None, hv, "historical"))
            continue

        key = (p.ticker, p.expiry)
        if key not in chains:
            try:
                chains[key] = load_chain(p.ticker, p.expiry, cache_dir, max_age_hours, refresh, downloader)
            except Exception as e:  # network error, expiry not listed, bad response...
                chains[key] = e
        chain = chains[key]

        if isinstance(chain, Exception):
            reason = str(chain) if isinstance(chain, ExpiryNotListed) else f"option chain unavailable ({chain})"
            out.append(VolChoice(p, hv, None, hv, "historical", reason))
            continue

        row = find_contract(chain, p.option_type, p.strike)
        if row is None:
            out.append(VolChoice(p, hv, None, hv, "historical", "strike not found in option chain"))
            continue

        iv = _num(row["impliedVolatility"])
        problem = quote_problem(iv, row["bid"], row["ask"])
        if problem:
            out.append(VolChoice(p, hv, None if math.isnan(iv) else iv, hv, "historical", problem))
        else:
            out.append(VolChoice(p, hv, iv, iv, "chain"))

    return out
