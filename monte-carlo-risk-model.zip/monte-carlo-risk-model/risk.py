"""Portfolio revaluation on simulated paths and risk statistics.

How the P&L distribution is built
---------------------------------
For every simulated path we ask: "if the world turns out like this path, what
is each option worth at the horizon date?"

* If the option expires on or before the horizon, it has already settled. Its
  value is the intrinsic payoff, max(S-K, 0) or max(K-S, 0), using that path's
  price *on the expiry date*. The cash is assumed to be held without interest.
* Otherwise it is still alive, and we value it with Black-Scholes, using the
  path's price at the horizon, the time still remaining until expiry, the
  constant rate, and that contract's pricing volatility (normally its implied
  vol from the option market, held fixed: the same vol is used today and at
  the horizon, whatever path the stock took).

Position P&L = (value at horizon - entry price) x quantity x 100.
Portfolio P&L is the sum across positions, path by path, so correlations between
underlyings (and offsetting longs and shorts) are captured automatically.

Risk measures (losses quoted as positive dollar amounts)
---------------------------------------------------------
VaR 95%   the loss that is exceeded on only 5% of paths. "On 19 out of 20
          scenarios we lose less than this."
CVaR 95%  (Expected Shortfall) the average loss across those worst 5% of paths.
          It answers "when things go badly, how badly on average?", and is never
          smaller than VaR.
"""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from datetime import date

import numpy as np
from numpy.typing import NDArray

from portfolio import CONTRACT_MULTIPLIER, Position
from pricing import bs_greeks, bs_price, intrinsic_value
from simulate import SimulationResult

DAYS_PER_YEAR = 365.0  # calendar-day convention for time to expiry


def horizon_date(valuation_date: date, horizon_days: int) -> date:
    """Calendar date reached after `horizon_days` business days (weekends skipped;
    exchange holidays are ignored)."""
    return np.busday_offset(np.datetime64(valuation_date, "D"), horizon_days, roll="forward").astype(date)


def business_days_between(start: date, end: date) -> int:
    """Number of business-day steps from `start` to `end` (an expiry falling on a
    weekend is treated as the preceding Friday)."""
    end_bd = np.busday_offset(np.datetime64(end, "D"), 0, roll="backward")
    return int(np.busday_count(np.datetime64(start, "D"), end_bd))


def year_fraction(start: date, end: date) -> float:
    """Calendar time between two dates in years (actual/365)."""
    return (end - start).days / DAYS_PER_YEAR


# --- Per-position revaluation ------------------------------------------------

def value_at_horizon(
    position: Position,
    sim: SimulationResult,
    valuation_date: date,
    horizon_days: int,
    rate: float,
    vol: float,
) -> NDArray[np.float64]:
    """Per-share value of one position on every path at the horizon, shape (n_paths,)."""
    paths = sim.ticker_paths(position.ticker)
    n_steps = paths.shape[1] - 1
    h_date = horizon_date(valuation_date, horizon_days)

    if position.expiry <= h_date:
        # Settled: payoff on the expiry date's simulated price.
        step = int(np.clip(business_days_between(valuation_date, position.expiry), 0, n_steps))
        return intrinsic_value(paths[:, step], position.strike, position.option_type)

    tau = year_fraction(h_date, position.expiry)
    return bs_price(paths[:, -1], position.strike, tau, rate, vol, position.option_type)


@dataclass(frozen=True)
class PositionSnapshot:
    """Today's mark-to-model value and Greeks for one position, in dollars
    (already multiplied by quantity x 100)."""

    position: Position
    spot: float
    vol: float               # volatility used to price this contract
    unit_value: float        # Black-Scholes value per share today
    market_value: float      # unit_value x qty x 100
    unrealized_pnl: float    # (unit_value - entry_price) x qty x 100
    delta: float             # $ change per $1 move in the underlying
    gamma: float             # change in delta per $1 move
    vega: float              # $ change per 1 vol point (1%)
    theta: float             # $ change per calendar day


def snapshot(position: Position, spot: float, vol: float, rate: float, valuation_date: date) -> PositionSnapshot:
    """Value and Greeks of a position today."""
    T = year_fraction(valuation_date, position.expiry)
    args = (spot, position.strike, T, rate, vol, position.option_type)
    unit = float(bs_price(*args))
    g = bs_greeks(*args)
    scale = position.quantity * CONTRACT_MULTIPLIER
    return PositionSnapshot(
        position=position,
        spot=spot,
        vol=vol,
        unit_value=unit,
        market_value=unit * scale,
        unrealized_pnl=(unit - position.entry_price) * scale,
        delta=float(g["delta"]) * scale,
        gamma=float(g["gamma"]) * scale,
        vega=float(g["vega"]) / 100 * scale,
        theta=float(g["theta"]) / DAYS_PER_YEAR * scale,
    )


# --- Risk statistics ---------------------------------------------------------

@dataclass(frozen=True)
class RiskMetrics:
    """Summary of a P&L distribution. VaR/CVaR are positive numbers meaning
    "dollars lost"; max_loss/max_gain are the signed worst and best P&L."""

    mean: float
    median: float
    std: float
    prob_profit: float
    var_95: float
    cvar_95: float
    var_99: float
    cvar_99: float
    max_loss: float
    max_gain: float
    n_paths: int


def var_cvar(pnl: NDArray[np.float64], confidence: float) -> tuple[float, float]:
    """Value-at-Risk and Conditional VaR at `confidence` (e.g. 0.95).

    VaR is the (1 - confidence) quantile of P&L, sign-flipped so a loss is
    positive. CVaR averages every P&L at or below that quantile.
    """
    if not 0 < confidence < 1:
        raise ValueError("confidence must be in (0, 1)")
    pnl = np.asarray(pnl, dtype=float)
    q = np.quantile(pnl, 1.0 - confidence)
    tail = pnl[pnl <= q]
    return float(-q), float(-tail.mean())


def risk_metrics(pnl: NDArray[np.float64]) -> RiskMetrics:
    """Compute the standard summary statistics of a simulated P&L distribution."""
    pnl = np.asarray(pnl, dtype=float)
    if pnl.ndim != 1 or pnl.size == 0:
        raise ValueError("pnl must be a non-empty 1-D array")
    v95, c95 = var_cvar(pnl, 0.95)
    v99, c99 = var_cvar(pnl, 0.99)
    return RiskMetrics(
        mean=float(pnl.mean()),
        median=float(np.median(pnl)),
        std=float(pnl.std(ddof=1)) if pnl.size > 1 else 0.0,
        prob_profit=float((pnl > 0).mean()),
        var_95=v95,
        cvar_95=c95,
        var_99=v99,
        cvar_99=c99,
        max_loss=float(pnl.min()),
        max_gain=float(pnl.max()),
        n_paths=int(pnl.size),
    )


# --- Portfolio-level driver -------------------------------------------------

@dataclass(frozen=True)
class RiskReport:
    """Everything produced by a portfolio risk run."""

    valuation_date: date
    horizon_date: date
    positions: list[Position]
    snapshots: list[PositionSnapshot]
    position_pnl: NDArray[np.float64]   # (n_paths, n_positions), vs. entry price
    pnl: NDArray[np.float64]            # (n_paths,), portfolio P&L vs. entry price
    pnl_from_today: NDArray[np.float64] # (n_paths,), P&L vs. today's model value
    metrics: RiskMetrics
    metrics_from_today: RiskMetrics


def run_risk(
    positions: Sequence[Position],
    sim: SimulationResult,
    vols: Mapping[str, float],
    rate: float,
    valuation_date: date,
    pricing_vols: Sequence[float] | None = None,
) -> RiskReport:
    """Reprice every position on every path at the horizon and summarize P&L.

    `vols` are per-ticker (historical) vols. `pricing_vols`, if given, is one
    volatility per position (e.g. that contract's implied vol) and is used for
    Black-Scholes both today and at the horizon; otherwise each position is
    priced at its ticker's vol. The paths in `sim` are not affected by this
    choice: they were simulated beforehand.

    Two P&L views are produced:
    * vs. entry price (what the spec asks for): includes gains/losses already
      locked in between entry and today.
    * vs. today's Black-Scholes value: isolates the risk from here to the horizon.
    """
    positions = list(positions)
    horizon_days = sim.paths.shape[1] - 1
    h_date = horizon_date(valuation_date, horizon_days)

    if pricing_vols is None:
        pv = [float(vols[p.ticker]) for p in positions]
    else:
        pv = [float(v) for v in pricing_vols]
        if len(pv) != len(positions):
            raise ValueError(f"got {len(pv)} pricing vols for {len(positions)} positions")

    unit_values = np.column_stack([
        value_at_horizon(p, sim, valuation_date, horizon_days, rate, v) for p, v in zip(positions, pv)
    ])
    qty = np.array([p.quantity for p in positions], dtype=float) * CONTRACT_MULTIPLIER
    entry = np.array([p.entry_price for p in positions])

    snaps = [
        snapshot(p, float(sim.paths[0, 0, sim.tickers.index(p.ticker)]), v, rate, valuation_date)
        for p, v in zip(positions, pv)
    ]
    today = np.array([s.unit_value for s in snaps])

    position_pnl = (unit_values - entry) * qty
    pnl = position_pnl.sum(axis=1)
    pnl_today = ((unit_values - today) * qty).sum(axis=1)

    return RiskReport(
        valuation_date=valuation_date,
        horizon_date=h_date,
        positions=positions,
        snapshots=snaps,
        position_pnl=position_pnl,
        pnl=pnl,
        pnl_from_today=pnl_today,
        metrics=risk_metrics(pnl),
        metrics_from_today=risk_metrics(pnl_today),
    )
