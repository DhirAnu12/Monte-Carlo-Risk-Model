"""Charts: P&L histogram with VaR markers, and per-ticker fan charts of simulated paths."""

from __future__ import annotations

from pathlib import Path

import matplotlib

matplotlib.use("Agg")  # file output only; no display needed
matplotlib.rcParams["text.parse_math"] = False  # "$" in labels is currency, not LaTeX
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.patches import Patch
from matplotlib.ticker import FuncFormatter, MaxNLocator

from portfolio import Position
from risk import RiskMetrics
from simulate import SimulationResult

# Reference palette (light mode)
SURFACE = "#fcfcfb"
INK = "#0b0b0b"
INK_2 = "#52514e"
GRID = "#e4e3df"
GAIN = "#2a78d6"   # diverging pole: blue
LOSS = "#e34948"   # diverging pole: red
BAND_OUTER = "#cde2fb"   # blue 100
BAND_INNER = "#86b6ef"   # blue 250
MEDIAN = "#1c5cab"       # blue 550
SAMPLE = "#a8a7a2"

_dollars = FuncFormatter(lambda x, _: f"-${abs(x):,.0f}" if x < 0 else f"${x:,.0f}")


def _style(ax: plt.Axes) -> None:
    ax.set_facecolor(SURFACE)
    for side in ("top", "right"):
        ax.spines[side].set_visible(False)
    for side in ("left", "bottom"):
        ax.spines[side].set_color(GRID)
    ax.tick_params(colors=INK_2, labelsize=9, length=0)
    ax.grid(True, axis="y", color=GRID, linewidth=0.8)
    ax.set_axisbelow(True)


def pnl_histogram(pnl: np.ndarray, metrics: RiskMetrics, path: str | Path, title: str) -> Path:
    """Histogram of portfolio P&L. Loss bins are red, gain bins blue; dashed and
    solid ink lines mark the 95% and 99% VaR, a dotted line marks the mean."""
    path = Path(path)
    fig, ax = plt.subplots(figsize=(10, 5.5), facecolor=SURFACE)
    _style(ax)

    lo, hi = np.percentile(pnl, [0.05, 99.95])  # clip extreme tails so the body is readable
    bins = np.linspace(lo, hi, 80)
    if lo < 0 < hi:  # put a bin edge exactly at zero so no bin straddles gain/loss
        bins = np.unique(np.concatenate([bins, [0.0]]))
    counts, edges = np.histogram(np.clip(pnl, lo, hi), bins=bins)
    centers = 0.5 * (edges[:-1] + edges[1:])
    widths = np.diff(edges)
    colors = np.where(centers < 0, LOSS, GAIN)
    ax.bar(centers, counts, width=widths * 0.9, color=colors, linewidth=0)

    # Reserve headroom above the bars so marker labels never sit on data.
    ymax = counts.max()
    ax.set_ylim(0, ymax * 1.32)
    markers = [  # (x, linestyle, label, label height as fraction of ymax, text side)
        (-metrics.var_99, "-", f"99% VaR  {_dollars(-metrics.var_99)}", 1.28, "left"),
        (-metrics.var_95, "--", f"95% VaR  {_dollars(-metrics.var_95)}", 1.15, "left"),
        (metrics.mean, ":", f"Mean  {_dollars(metrics.mean)}", 1.28, "left"),
    ]
    for x, ls, label, yfrac, side in markers:
        ax.axvline(x, color=INK, linestyle=ls, linewidth=1.5)
        ax.annotate(label, (x, ymax * yfrac), xytext=(5 if side == "left" else -5, 0),
                    textcoords="offset points", color=INK, fontsize=9, va="top",
                    ha="left" if side == "left" else "right",
                    bbox=dict(boxstyle="round,pad=0.2", fc=SURFACE, ec="none"))

    ax.xaxis.set_major_formatter(_dollars)
    ax.set_xlabel("Portfolio P&L at horizon", color=INK_2, fontsize=10)
    ax.set_ylabel("Paths", color=INK_2, fontsize=10)
    ax.set_title(title, color=INK, fontsize=13, loc="left", pad=14)
    ax.text(0, 1.01, f"{metrics.n_paths:,} paths  ·  P(profit) {metrics.prob_profit:.1%}  ·  "
            f"CVaR 95% {_dollars(-metrics.cvar_95)}  ·  CVaR 99% {_dollars(-metrics.cvar_99)}",
            transform=ax.transAxes, color=INK_2, fontsize=9)
    ax.legend(handles=[Patch(color=LOSS, label="Loss"), Patch(color=GAIN, label="Gain")],
              frameon=False, loc="upper right", fontsize=9, labelcolor=INK)

    fig.tight_layout()
    fig.savefig(path, dpi=150, facecolor=SURFACE)
    plt.close(fig)
    return path


def fan_chart(sim: SimulationResult, positions: list[Position], path: str | Path,
              title: str, n_samples: int = 25) -> Path:
    """One panel per ticker: 5-95% and 25-75% percentile bands, median path, a
    handful of individual sample paths, and each position's strike."""
    path = Path(path)
    n = len(sim.tickers)
    fig, axes = plt.subplots(1, n, figsize=(5.2 * n, 4.6), facecolor=SURFACE, squeeze=False)
    days = np.arange(sim.paths.shape[1])
    rng = np.random.default_rng(0)
    sample_idx = rng.choice(sim.paths.shape[0], size=min(n_samples, sim.paths.shape[0]), replace=False)

    for ax, ticker in zip(axes[0], sim.tickers):
        _style(ax)
        p = sim.ticker_paths(ticker)
        q5, q25, q50, q75, q95 = np.percentile(p, [5, 25, 50, 75, 95], axis=0)
        ax.plot(days, p[sample_idx].T, color=SAMPLE, linewidth=0.6, alpha=0.5, zorder=1)
        ax.fill_between(days, q5, q95, color=BAND_OUTER, alpha=0.85, linewidth=0, label="5–95%", zorder=2)
        ax.fill_between(days, q25, q75, color=BAND_INNER, alpha=0.9, linewidth=0, label="25–75%", zorder=3)
        ax.plot(days, q50, color=MEDIAN, linewidth=2, label="Median", zorder=4)

        for strike in sorted({pos.strike for pos in positions if pos.ticker == ticker}):
            ax.axhline(strike, color=INK_2, linestyle=":", linewidth=1, zorder=5)
            ax.annotate(f"K {strike:g}", (days[-1], strike), xytext=(-2, 3), textcoords="offset points",
                        ha="right", va="bottom", color=INK_2, fontsize=8)

        ax.set_title(f"{ticker}  ·  spot ${p[0, 0]:,.2f}", color=INK, fontsize=11, loc="left")
        ax.set_xlabel("Trading days ahead", color=INK_2, fontsize=9)
        ax.set_xlim(0, days[-1])
        ax.xaxis.set_major_locator(MaxNLocator(integer=True))
        ax.yaxis.set_major_formatter(FuncFormatter(lambda x, _: f"${x:,.0f}"))

    axes[0][0].legend(frameon=False, loc="upper left", fontsize=8, labelcolor=INK)
    fig.suptitle(title, color=INK, fontsize=13, x=0.01, ha="left")
    fig.tight_layout()
    fig.savefig(path, dpi=150, facecolor=SURFACE)
    plt.close(fig)
    return path
