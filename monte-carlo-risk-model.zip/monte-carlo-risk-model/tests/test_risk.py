"""Tests for revaluation and risk metrics."""

from datetime import date

import numpy as np
import pytest

from portfolio import Position
from pricing import bs_price
from risk import (
    business_days_between,
    horizon_date,
    risk_metrics,
    run_risk,
    value_at_horizon,
    var_cvar,
)
from simulate import SimulationResult, simulate_gbm

VAL = date(2026, 11, 11)  # a Wednesday


def make_sim(paths_by_ticker: dict[str, list[list[float]]]) -> SimulationResult:
    tickers = list(paths_by_ticker)
    arr = np.stack([np.asarray(v, dtype=float) for v in paths_by_ticker.values()], axis=-1)
    return SimulationResult(tickers=tickers, paths=arr, dt=1 / 252)


# --- Dates -------------------------------------------------------------------

def test_horizon_date_skips_weekends():
    assert horizon_date(VAL, 2) == date(2026, 11, 13)   # Fri
    assert horizon_date(VAL, 3) == date(2026, 11, 16)   # Mon
    assert horizon_date(VAL, 0) == VAL


def test_business_days_between():
    assert business_days_between(VAL, date(2026, 11, 13)) == 2
    assert business_days_between(VAL, date(2026, 11, 14)) == 2  # Sat -> Fri
    assert business_days_between(VAL, horizon_date(VAL, 21)) == 21


# --- Revaluation ---------------------------------------------------------------

def test_expired_option_uses_price_on_expiry_date():
    # 3-step paths: Wed(0) Thu(1) Fri(2) Mon(3). Option expires Thu.
    sim = make_sim({"X": [[100, 120, 90, 80], [100, 95, 130, 140]]})
    call = Position("X", "call", 100, date(2026, 11, 12), 1, 1.0)
    v = value_at_horizon(call, sim, VAL, 3, 0.04, 0.2)
    np.testing.assert_allclose(v, [20.0, 0.0])  # not the horizon prices 80 / 140


def test_live_option_uses_black_scholes_with_remaining_time():
    sim = make_sim({"X": [[100, 101, 102, 110], [100, 99, 98, 90]]})
    exp = date(2027, 2, 16)
    put = Position("X", "put", 100, exp, -2, 3.0)
    v = value_at_horizon(put, sim, VAL, 3, 0.04, 0.3)
    tau = (exp - date(2026, 11, 16)).days / 365
    np.testing.assert_allclose(v, bs_price([110, 90], 100, tau, 0.04, 0.3, "put"))


def test_portfolio_pnl_hand_computed():
    """Long 2 calls, short 1 put, both expiring before the horizon -> pure intrinsic."""
    sim = make_sim({
        "A": [[100, 100, 110], [100, 100, 90]],
        "B": [[50, 50, 45], [50, 50, 55]],
    })
    exp = date(2026, 11, 13)  # = horizon (2 bdays)
    positions = [
        Position("A", "call", 100, exp, 2, 4.0),   # payoff 10 / 0
        Position("B", "put", 50, exp, -1, 2.0),    # payoff 5 / 0
    ]
    rep = run_risk(positions, sim, {"A": 0.2, "B": 0.3}, 0.04, VAL)
    # Path 1: A (10-4)*2*100 = 1200, B (5-2)*-1*100 = -300 -> 900
    # Path 2: A (0-4)*2*100  = -800, B (0-2)*-1*100 = +200 -> -600
    np.testing.assert_allclose(rep.position_pnl, [[1200, -300], [-800, 200]])
    np.testing.assert_allclose(rep.pnl, [900, -600])
    assert rep.horizon_date == exp


def test_pnl_from_today_has_mean_near_zero_under_risk_neutral_drift():
    """With r = 0 and risk-neutral drift, the option's price is a martingale:
    the expected Black-Scholes value at the horizon equals today's value, so mean
    P&L vs. today's value should be zero up to Monte Carlo noise."""
    sim = simulate_gbm(["X"], [100.0], [0.25], [[1.0]], 21, n_paths=100_000, rate=0.0, seed=5)
    pos = [Position("X", "call", 105, date(2027, 6, 18), 10, 0.0)]
    rep = run_risk(pos, sim, {"X": 0.25}, 0.0, VAL)
    se = rep.pnl_from_today.std() / np.sqrt(len(rep.pnl_from_today))
    assert abs(rep.metrics_from_today.mean) < 4 * se


def test_snapshot_values():
    sim = make_sim({"X": [[100, 100]]})
    pos = Position("X", "call", 100, date(2027, 11, 11), -3, 5.0)
    rep = run_risk([pos], sim, {"X": 0.2}, 0.05, VAL)
    s = rep.snapshots[0]
    unit = bs_price(100, 100, 1.0, 0.05, 0.2, "call")
    assert s.unit_value == pytest.approx(unit)
    assert s.market_value == pytest.approx(unit * -300)
    assert s.unrealized_pnl == pytest.approx((unit - 5.0) * -300)
    assert s.delta < 0  # short call


# --- Metrics -------------------------------------------------------------------

def test_var_cvar_known_distribution():
    pnl = np.arange(-50, 50, dtype=float)  # 100 equally likely outcomes
    var, cvar = var_cvar(pnl, 0.95)
    q = np.quantile(pnl, 0.05)  # -45.05
    assert var == pytest.approx(-q)
    assert cvar == pytest.approx(-np.mean([-50, -49, -48, -47, -46]))
    assert cvar >= var


def test_var_cvar_normal():
    pnl = np.random.default_rng(0).normal(0, 1000, 1_000_000)
    var, cvar = var_cvar(pnl, 0.99)
    assert var == pytest.approx(2326.3, rel=0.01)    # z_0.99 * sigma
    assert cvar == pytest.approx(2665.2, rel=0.01)   # sigma * pdf(z) / 0.01


def test_risk_metrics_summary():
    pnl = np.array([-300.0, -100.0, 0.0, 50.0, 250.0])
    m = risk_metrics(pnl)
    assert m.mean == pytest.approx(-20.0)
    assert m.median == 0.0
    assert m.prob_profit == pytest.approx(0.4)  # zero is not a profit
    assert m.max_loss == -300.0
    assert m.max_gain == 250.0
    assert m.n_paths == 5


def test_risk_metrics_validation():
    with pytest.raises(ValueError):
        risk_metrics(np.array([]))
    with pytest.raises(ValueError):
        var_cvar(np.array([1.0]), 1.5)


def test_pricing_vols_used_today_and_at_horizon():
    """Per-position pricing vols drive Black-Scholes both in the snapshot and at the horizon."""
    sim = make_sim({"X": [[100, 101, 102, 110], [100, 99, 98, 90]]})
    exp = date(2027, 2, 16)
    p = Position("X", "call", 100, exp, 1, 0.0)
    rep_hist = run_risk([p], sim, {"X": 0.20}, 0.04, VAL)
    rep_iv = run_risk([p], sim, {"X": 0.20}, 0.04, VAL, pricing_vols=[0.35])

    T0 = (exp - VAL).days / 365
    tau = (exp - date(2026, 11, 16)).days / 365
    assert rep_iv.snapshots[0].unit_value == pytest.approx(bs_price(100, 100, T0, 0.04, 0.35, "call"))
    assert rep_iv.snapshots[0].vol == 0.35
    np.testing.assert_allclose(rep_iv.pnl, bs_price([110, 90], 100, tau, 0.04, 0.35, "call") * 100)
    assert rep_hist.snapshots[0].vol == 0.20
    assert np.all(rep_iv.pnl > rep_hist.pnl)  # higher vol -> higher call value


def test_pricing_vols_length_checked():
    sim = make_sim({"X": [[100, 100]]})
    with pytest.raises(ValueError, match="pricing vols"):
        run_risk([Position("X", "call", 100, date(2027, 1, 1), 1, 1.0)], sim, {"X": 0.2}, 0.04, VAL,
                 pricing_vols=[0.2, 0.3])
