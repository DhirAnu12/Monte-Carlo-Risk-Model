"""Tests for implied-vol lookup, fallback and override (no network access)."""

from datetime import date

import pandas as pd
import pytest

import implied_vol
from implied_vol import ExpiryNotListed, load_chain, quote_problem, resolve_pricing_vols
from portfolio import Position

VAL = date(2026, 11, 11)
EXP = date(2027, 1, 15)
HIST = {"AAA": 0.30, "BBB": 0.20}


def chain(*rows) -> pd.DataFrame:
    """rows: (type, strike, bid, ask, iv)"""
    return pd.DataFrame(rows, columns=["type", "strike", "bid", "ask", "impliedVolatility"])


GOOD_CHAIN = chain(
    ("call", 100.0, 5.0, 5.2, 0.27),
    ("call", 110.0, 2.0, 2.1, 0.25),
    ("put", 90.0, 1.0, 1.1, 0.33),
    ("call", 120.0, 0.0, 0.0, 0.00001),     # dead quote with placeholder IV
    ("call", 130.0, 0.0, 0.05, 0.40),       # no bid
    ("put", 80.0, 0.5, 0.6, 0.0),           # zero IV
    ("put", 70.0, float("nan"), 0.3, 0.5),  # missing bid
)


class FakeDownloader:
    """Records calls; returns a chain per (ticker, expiry) or raises."""

    def __init__(self, chains=None, error=None):
        self.chains = chains or {}
        self.error = error
        self.calls = []

    def __call__(self, ticker, expiry):
        self.calls.append((ticker, expiry))
        if self.error:
            raise self.error
        if (ticker, expiry) not in self.chains:
            raise ExpiryNotListed(f"{ticker} has no listed options expiring {expiry}")
        return self.chains[(ticker, expiry)]


def pos(ticker="AAA", typ="call", strike=100.0, expiry=EXP, iv=None) -> Position:
    return Position(ticker, typ, strike, expiry, 1, 1.0, iv)


def resolve(positions, dl, tmp_path, **kw):
    return resolve_pricing_vols(positions, HIST, VAL, cache_dir=tmp_path, downloader=dl, **kw)


# --- Happy path ------------------------------------------------------------------

def test_uses_chain_iv_for_exact_contract(tmp_path):
    dl = FakeDownloader({("AAA", EXP): GOOD_CHAIN})
    c1, c2, c3 = resolve([pos(), pos(strike=110.0), pos(typ="put", strike=90.0)], dl, tmp_path)
    assert (c1.source, c1.pricing_vol, c1.warning) == ("chain", 0.27, None)
    assert c2.pricing_vol == 0.25
    assert c3.pricing_vol == 0.33  # put row, not a call at the same strike
    assert all(c.hist_vol == 0.30 for c in (c1, c2, c3))
    assert len(dl.calls) == 1  # one download per (ticker, expiry)


# --- Fallback ----------------------------------------------------------------------

@pytest.mark.parametrize(
    "typ,strike,expected_reason",
    [
        ("call", 120.0, "effectively zero"),
        ("call", 130.0, "no two-sided quote"),
        ("put", 80.0, "effectively zero"),
        ("put", 70.0, "no two-sided quote"),
        ("call", 105.0, "strike not found"),
    ],
)
def test_broken_or_missing_quote_falls_back_to_historical(tmp_path, typ, strike, expected_reason):
    dl = FakeDownloader({("AAA", EXP): GOOD_CHAIN})
    (c,) = resolve([pos(typ=typ, strike=strike)], dl, tmp_path)
    assert c.source == "historical"
    assert c.pricing_vol == HIST["AAA"]
    assert expected_reason in c.warning


def test_rejected_iv_is_still_reported(tmp_path):
    """A broken IV that exists (e.g. 0.00001) is shown, but not used."""
    dl = FakeDownloader({("AAA", EXP): GOOD_CHAIN})
    (c,) = resolve([pos(strike=120.0)], dl, tmp_path)
    assert c.implied_vol == pytest.approx(0.00001)
    assert c.pricing_vol == 0.30


def test_unlisted_expiry_falls_back(tmp_path):
    (c,) = resolve([pos(expiry=date(2027, 1, 14))], FakeDownloader(), tmp_path)
    assert c.source == "historical"
    assert "no listed options expiring" in c.warning


def test_download_failure_falls_back_for_every_position(tmp_path):
    dl = FakeDownloader(error=ConnectionError("offline"))
    choices = resolve([pos(), pos(strike=110.0), pos("BBB")], dl, tmp_path)
    assert [c.pricing_vol for c in choices] == [0.30, 0.30, 0.20]
    assert all("option chain unavailable" in c.warning and "offline" in c.warning for c in choices)
    assert len(dl.calls) == 2  # failure for AAA/EXP is remembered, not retried


def test_expired_position_skips_lookup_quietly(tmp_path):
    dl = FakeDownloader({("AAA", EXP): GOOD_CHAIN})
    (c,) = resolve([pos(expiry=date(2026, 11, 1))], dl, tmp_path)
    assert c.source == "historical" and c.warning is None
    assert dl.calls == []


def test_no_iv_mode_uses_historical_without_warnings(tmp_path):
    dl = FakeDownloader({("AAA", EXP): GOOD_CHAIN})
    choices = resolve([pos(), pos(strike=120.0)], dl, tmp_path, use_market_iv=False)
    assert [c.pricing_vol for c in choices] == [0.30, 0.30]
    assert all(c.warning is None for c in choices)
    assert dl.calls == []


# --- Override ---------------------------------------------------------------------

def test_override_wins_and_skips_download(tmp_path):
    dl = FakeDownloader({("AAA", EXP): GOOD_CHAIN})
    (c,) = resolve([pos(iv=0.42)], dl, tmp_path)
    assert (c.source, c.pricing_vol, c.implied_vol, c.warning) == ("override", 0.42, 0.42, None)
    assert dl.calls == []


def test_override_applies_even_with_no_iv_flag(tmp_path):
    (c,) = resolve([pos(iv=0.42)], FakeDownloader(), tmp_path, use_market_iv=False)
    assert c.pricing_vol == 0.42


def test_override_beats_broken_quote(tmp_path):
    dl = FakeDownloader({("AAA", EXP): GOOD_CHAIN})
    (c,) = resolve([pos(strike=120.0, iv=0.35)], dl, tmp_path)
    assert c.source == "override" and c.warning is None


# --- Quote checks ---------------------------------------------------------------------

@pytest.mark.parametrize(
    "iv,bid,ask,ok",
    [
        (0.25, 1.0, 1.1, True),
        (0.0, 1.0, 1.1, False),
        (0.005, 1.0, 1.1, False),
        (7.0, 1.0, 1.1, False),
        (None, 1.0, 1.1, False),
        (0.25, 0.0, 1.1, False),
        (0.25, 1.0, 0.0, False),
        (0.25, None, 1.1, False),
        (0.25, 1.2, 1.1, False),  # crossed
    ],
)
def test_quote_problem(iv, bid, ask, ok):
    assert (quote_problem(iv, bid, ask) is None) == ok


# --- Caching -------------------------------------------------------------------------

def test_chain_cache_roundtrip_and_refresh(tmp_path):
    dl = FakeDownloader({("AAA", EXP): GOOD_CHAIN})
    a = load_chain("AAA", EXP, cache_dir=tmp_path, downloader=dl)
    b = load_chain("AAA", EXP, cache_dir=tmp_path, downloader=dl)
    assert len(dl.calls) == 1
    assert (tmp_path / "chain_AAA_2027-01-15.csv").exists()
    pd.testing.assert_frame_equal(a.reset_index(drop=True), b)
    load_chain("AAA", EXP, cache_dir=tmp_path, downloader=dl, refresh=True)
    assert len(dl.calls) == 2


def test_resolve_reads_from_cache_when_offline(tmp_path):
    load_chain("AAA", EXP, cache_dir=tmp_path, downloader=FakeDownloader({("AAA", EXP): GOOD_CHAIN}))
    (c,) = resolve([pos()], FakeDownloader(error=ConnectionError("offline")), tmp_path)
    assert c.source == "chain" and c.pricing_vol == 0.27  # fresh cache, no download attempted


def test_stale_chain_cache_used_when_download_fails(tmp_path):
    load_chain("AAA", EXP, cache_dir=tmp_path, downloader=FakeDownloader({("AAA", EXP): GOOD_CHAIN}))
    stale = load_chain("AAA", EXP, cache_dir=tmp_path, max_age_hours=0,
                       downloader=FakeDownloader(error=ConnectionError("offline")))
    assert len(stale) == len(GOOD_CHAIN)


def test_default_downloader_is_looked_up_at_call_time(tmp_path, monkeypatch):
    """So tests (and callers) can swap the yfinance downloader module-wide."""
    monkeypatch.setattr(implied_vol, "_yfinance_chain", FakeDownloader({("AAA", EXP): GOOD_CHAIN}))
    (c,) = resolve_pricing_vols([pos()], HIST, VAL, cache_dir=tmp_path)
    assert c.pricing_vol == 0.27
