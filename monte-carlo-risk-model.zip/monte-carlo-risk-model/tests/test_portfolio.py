"""Tests for loading positions from CSV."""

from datetime import date
from pathlib import Path

import pytest

from portfolio import PortfolioError, load_positions, tickers_of

HEADER = "ticker,type,strike,expiry,quantity,entry_price\n"


def write(tmp_path: Path, body: str, header: str = HEADER) -> Path:
    p = tmp_path / "pos.csv"
    p.write_text(header + body)
    return p


def test_sample_file_loads():
    positions = load_positions(Path(__file__).parent.parent / "positions.csv")
    assert len(positions) == 5
    assert tickers_of(positions) == ["AAPL", "MSFT", "SPY"]
    assert any(p.quantity < 0 for p in positions)


def test_parses_fields(tmp_path):
    (p,) = load_positions(write(tmp_path, " aapl , CALL ,150,2027-01-15,-3,2.5\n"))
    assert p.ticker == "AAPL"
    assert p.option_type == "call"
    assert p.strike == 150.0
    assert p.expiry == date(2027, 1, 15)
    assert p.quantity == -3
    assert not p.is_long
    assert p.cost_basis == pytest.approx(-750.0)
    assert p.label() == "Short 3 AAPL 150C 2027-01-15"


def test_blank_lines_skipped(tmp_path):
    assert len(load_positions(write(tmp_path, "A,put,10,2027-01-01,1,1\n\n,,,,,\n"))) == 1


@pytest.mark.parametrize(
    "row",
    [
        "A,straddle,10,2027-01-01,1,1",   # bad type
        "A,call,-10,2027-01-01,1,1",      # negative strike
        "A,call,10,01/01/2027,1,1",       # bad date format
        "A,call,10,2027-01-01,0,1",       # zero quantity
        "A,call,10,2027-01-01,1.5,1",     # fractional contracts
        "A,call,10,2027-01-01,1,-1",      # negative premium
        "A,call,abc,2027-01-01,1,1",      # non-numeric
    ],
)
def test_rejects_bad_rows(tmp_path, row):
    with pytest.raises(PortfolioError):
        load_positions(write(tmp_path, row + "\n"))


def test_missing_column(tmp_path):
    with pytest.raises(PortfolioError, match="missing columns"):
        load_positions(write(tmp_path, "A,call,10,2027-01-01,1\n", header="ticker,type,strike,expiry,quantity\n"))


def test_empty_file(tmp_path):
    with pytest.raises(PortfolioError, match="no positions"):
        load_positions(write(tmp_path, ""))


# --- Optional iv override column -----------------------------------------------

def test_iv_column_optional(tmp_path):
    (p,) = load_positions(write(tmp_path, "A,call,10,2027-01-01,1,1\n"))
    assert p.iv is None


def test_iv_column_parsed_and_blank_means_none(tmp_path):
    a, b = load_positions(write(
        tmp_path, "A,call,10,2027-01-01,1,1,0.32\nA,put,10,2027-01-01,1,1,\n",
        header="ticker,type,strike,expiry,quantity,entry_price,iv\n",
    ))
    assert a.iv == pytest.approx(0.32)
    assert b.iv is None


@pytest.mark.parametrize("iv", ["0", "-0.2", "25", "abc", "nan"])
def test_iv_column_rejects_bad_values(tmp_path, iv):
    with pytest.raises(PortfolioError):
        load_positions(write(tmp_path, f"A,call,10,2027-01-01,1,1,{iv}\n",
                             header="ticker,type,strike,expiry,quantity,entry_price,iv\n"))
