"""Tests for Black-Scholes pricing and Greeks."""

import itertools

import numpy as np
import pytest

from pricing import bs_greeks, bs_price, intrinsic_value


# --- Known values -----------------------------------------------------------

def test_hull_textbook_example():
    """Hull, Options Futures & Other Derivatives, Example 15.6:
    S=42, K=40, r=10%, sigma=20%, T=0.5 -> call 4.76, put 0.81."""
    call = bs_price(42, 40, 0.5, 0.10, 0.20, "call")
    put = bs_price(42, 40, 0.5, 0.10, 0.20, "put")
    assert call == pytest.approx(4.7594, abs=1e-3)
    assert put == pytest.approx(0.8086, abs=1e-3)


def test_atm_reference_value():
    """Widely quoted reference: S=K=100, r=5%, sigma=20%, T=1 -> call 10.4506, put 5.5735."""
    assert bs_price(100, 100, 1.0, 0.05, 0.20, "call") == pytest.approx(10.4506, abs=1e-4)
    assert bs_price(100, 100, 1.0, 0.05, 0.20, "put") == pytest.approx(5.5735, abs=1e-4)


def test_atm_greeks_reference():
    """Same ATM option: delta 0.6368, gamma 0.018762, vega 37.524, theta -6.414, rho 53.232."""
    g = bs_greeks(100, 100, 1.0, 0.05, 0.20, "call")
    assert g["delta"] == pytest.approx(0.63683, abs=1e-4)
    assert g["gamma"] == pytest.approx(0.018762, abs=1e-5)
    assert g["vega"] == pytest.approx(37.524, abs=1e-2)
    assert g["theta"] == pytest.approx(-6.414, abs=1e-2)
    assert g["rho"] == pytest.approx(53.232, abs=1e-2)


# --- Put-call parity --------------------------------------------------------

@pytest.mark.parametrize(
    "S,K,T,r,sigma",
    list(itertools.product([50, 100, 150], [80, 100, 120], [0.05, 0.5, 2.0], [0.0, 0.04], [0.1, 0.4])),
)
def test_put_call_parity(S, K, T, r, sigma):
    """C - P = S - K e^{-rT}, independent of volatility."""
    c = bs_price(S, K, T, r, sigma, "call")
    p = bs_price(S, K, T, r, sigma, "put")
    assert c - p == pytest.approx(S - K * np.exp(-r * T), abs=1e-9)


def test_put_call_parity_vectorized():
    rng = np.random.default_rng(0)
    S = rng.uniform(20, 200, 1000)
    K = rng.uniform(20, 200, 1000)
    T = rng.uniform(0.01, 3, 1000)
    sigma = rng.uniform(0.05, 0.8, 1000)
    r = 0.03
    lhs = bs_price(S, K, T, r, sigma, "call") - bs_price(S, K, T, r, sigma, "put")
    np.testing.assert_allclose(lhs, S - K * np.exp(-r * T), atol=1e-9)


# --- Greeks vs. finite differences -----------------------------------------

@pytest.mark.parametrize("opt", ["call", "put"])
@pytest.mark.parametrize("S", [80.0, 100.0, 125.0])
def test_greeks_match_finite_differences(opt, S):
    K, T, r, sigma = 100.0, 0.75, 0.03, 0.25
    g = bs_greeks(S, K, T, r, sigma, opt)
    h = 1e-4
    f = lambda **kw: bs_price(**{"S": S, "K": K, "T": T, "r": r, "sigma": sigma, "option_type": opt, **kw})

    assert g["delta"] == pytest.approx((f(S=S + h) - f(S=S - h)) / (2 * h), abs=1e-6)
    assert g["gamma"] == pytest.approx((f(S=S + h) - 2 * f() + f(S=S - h)) / h**2, abs=1e-4)
    assert g["vega"] == pytest.approx((f(sigma=sigma + h) - f(sigma=sigma - h)) / (2 * h), abs=1e-5)
    assert g["rho"] == pytest.approx((f(r=r + h) - f(r=r - h)) / (2 * h), abs=1e-5)
    # theta is d/dt with t = calendar time, i.e. -d/dT
    assert g["theta"] == pytest.approx(-(f(T=T + h) - f(T=T - h)) / (2 * h), abs=1e-5)


# --- Edge cases -------------------------------------------------------------

def test_expired_option_is_intrinsic():
    S = np.array([90.0, 100.0, 110.0])
    np.testing.assert_allclose(bs_price(S, 100, 0.0, 0.05, 0.2, "call"), [0, 0, 10])
    np.testing.assert_allclose(bs_price(S, 100, -1.0, 0.05, 0.2, "put"), [10, 0, 0])


def test_zero_vol_is_discounted_forward_payoff():
    S, K, T, r = 100.0, 95.0, 1.0, 0.05
    expected = np.exp(-r * T) * max(S * np.exp(r * T) - K, 0)
    assert bs_price(S, K, T, r, 0.0, "call") == pytest.approx(expected)


def test_price_bounds():
    """A call is worth at least its discounted intrinsic value and at most the stock."""
    S = np.linspace(1, 300, 200)
    c = bs_price(S, 100, 1.0, 0.05, 0.3, "call")
    assert np.all(c >= np.maximum(S - 100 * np.exp(-0.05), 0) - 1e-12)
    assert np.all(c <= S)


def test_scalar_in_scalar_out():
    assert np.ndim(bs_price(100, 100, 1, 0.05, 0.2, "call")) == 0


def test_bad_option_type():
    with pytest.raises(ValueError):
        bs_price(100, 100, 1, 0.05, 0.2, "straddle")
    with pytest.raises(ValueError):
        intrinsic_value(100, 100, "foo")
