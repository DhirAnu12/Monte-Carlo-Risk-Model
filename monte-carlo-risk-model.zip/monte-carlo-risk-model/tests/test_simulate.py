"""Tests for correlated GBM simulation, including MC-vs-Black-Scholes convergence."""

import numpy as np
import pytest

from pricing import bs_price
from simulate import TRADING_DAYS_PER_YEAR, safe_cholesky, simulate_gbm

TICKERS = ["A", "B", "C"]
SPOTS = [100.0, 50.0, 200.0]
VOLS = [0.20, 0.35, 0.15]
CORR = np.array([[1.0, 0.6, 0.3], [0.6, 1.0, -0.2], [0.3, -0.2, 1.0]])


def test_shape_and_start():
    res = simulate_gbm(TICKERS, SPOTS, VOLS, CORR, horizon_days=10, n_paths=500, seed=1)
    assert res.paths.shape == (500, 11, 3)
    np.testing.assert_array_equal(res.paths[:, 0, :], np.broadcast_to(SPOTS, (500, 3)))
    assert res.terminal.shape == (500, 3)
    assert res.ticker_paths("B").shape == (500, 11)
    assert np.all(res.paths > 0)


def test_seed_reproducibility():
    a = simulate_gbm(TICKERS, SPOTS, VOLS, CORR, 5, n_paths=100, seed=42).paths
    b = simulate_gbm(TICKERS, SPOTS, VOLS, CORR, 5, n_paths=100, seed=42).paths
    c = simulate_gbm(TICKERS, SPOTS, VOLS, CORR, 5, n_paths=100, seed=43).paths
    np.testing.assert_array_equal(a, b)
    assert not np.array_equal(a, c)


def test_correlation_and_vol_recovered():
    res = simulate_gbm(TICKERS, SPOTS, VOLS, CORR, horizon_days=20, n_paths=20_000, seed=7)
    log_ret = np.diff(np.log(res.paths), axis=1).reshape(-1, 3)
    np.testing.assert_allclose(np.corrcoef(log_ret.T), CORR, atol=0.01)
    ann_vol = log_ret.std(axis=0) * np.sqrt(TRADING_DAYS_PER_YEAR)
    np.testing.assert_allclose(ann_vol, VOLS, rtol=0.01)


def test_mean_terminal_matches_drift():
    """E[S_T] = S_0 e^{mu T}, with per-ticker drift overrides applied."""
    days = 126
    drift = {"A": 0.15}
    res = simulate_gbm(TICKERS, SPOTS, VOLS, CORR, days, n_paths=100_000, rate=0.03, drift=drift, seed=3)
    T = days / TRADING_DAYS_PER_YEAR
    mu = np.array([0.15, 0.03, 0.03])
    expected = np.array(SPOTS) * np.exp(mu * T)
    se = res.terminal.std(axis=0) / np.sqrt(res.terminal.shape[0])
    assert np.all(np.abs(res.terminal.mean(axis=0) - expected) < 4 * se)


def test_mc_call_converges_to_black_scholes():
    """Discounted mean payoff of a European call under risk-neutral GBM should
    match Black-Scholes within 3 standard errors, and the error should shrink
    as paths increase."""
    S0, K, sigma, r, days = 100.0, 105.0, 0.25, 0.04, 126
    T = days / TRADING_DAYS_PER_YEAR
    bs = bs_price(S0, K, T, r, sigma, "call")

    errors = []
    for n_paths in (2_000, 200_000):
        res = simulate_gbm(["X"], [S0], [sigma], [[1.0]], days, n_paths=n_paths, rate=r, seed=11)
        disc_payoff = np.exp(-r * T) * np.maximum(res.terminal[:, 0] - K, 0.0)
        mc = disc_payoff.mean()
        se = disc_payoff.std(ddof=1) / np.sqrt(n_paths)
        errors.append(abs(mc - bs))
        assert abs(mc - bs) < 3 * se, f"n={n_paths}: MC {mc:.4f} vs BS {bs:.4f} (se {se:.4f})"

    # With 200k paths the standard error is ~0.02, so the price is pinned down tightly.
    assert errors[-1] < 0.05


def test_antithetic():
    res = simulate_gbm(["X"], [100.0], [0.2], [[1.0]], 5, n_paths=1000, seed=0, antithetic=True)
    log_ret = np.log(res.terminal[:, 0] / 100.0)
    # Paired paths have mirror-image shocks around the drift term
    np.testing.assert_allclose(log_ret[:500] + log_ret[500:], 2 * (0.04 - 0.02) * 5 / 252)
    with pytest.raises(ValueError):
        simulate_gbm(["X"], [100.0], [0.2], [[1.0]], 5, n_paths=999, antithetic=True)


def test_safe_cholesky_repairs_non_pd_matrix():
    bad = np.array([[1.0, 0.99, 0.0], [0.99, 1.0, 0.99], [0.0, 0.99, 1.0]])  # not PSD
    with pytest.raises(np.linalg.LinAlgError):
        np.linalg.cholesky(bad)
    L = safe_cholesky(bad)
    C = L @ L.T
    np.testing.assert_allclose(np.diag(C), 1.0)


def test_input_validation():
    with pytest.raises(ValueError):
        simulate_gbm(["X"], [100.0], [0.2], [[1.0]], 0)
    with pytest.raises(ValueError):
        simulate_gbm(["X"], [100.0], [0.2], [[1.0]], 5, drift={"Y": 0.1})
    with pytest.raises(ValueError):
        simulate_gbm(["X", "Y"], [100.0, 50.0], [0.2, 0.3], [[1.0]], 5)
