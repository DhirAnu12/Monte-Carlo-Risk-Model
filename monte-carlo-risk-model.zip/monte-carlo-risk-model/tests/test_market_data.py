"""Tests for market data statistics and caching (no network access)."""

import numpy as np
import pandas as pd
import pytest

from market_data import compute_stats, get_market_data, load_closes


def synthetic_closes(n_days=253, vols=(0.2, 0.4), rho=0.5, seed=0) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    L = np.linalg.cholesky([[1, rho], [rho, 1]])
    z = rng.standard_normal((n_days - 1, 2)) @ L.T
    rets = z * np.array(vols) / np.sqrt(252)
    px = 100 * np.exp(np.vstack([np.zeros(2), np.cumsum(rets, axis=0)]))
    idx = pd.bdate_range("2025-01-01", periods=n_days)
    return pd.DataFrame(px, index=idx, columns=["AAA", "BBB"])


def test_compute_stats_matches_manual():
    closes = synthetic_closes()
    md = compute_stats(closes)
    lr = np.log(closes).diff().dropna()
    np.testing.assert_allclose(md.vols, lr.std().to_numpy() * np.sqrt(252))
    np.testing.assert_allclose(md.corr, lr.corr().to_numpy())
    np.testing.assert_allclose(md.spots, closes.iloc[-1].to_numpy())
    assert md.n_obs == len(closes) - 1
    assert md.spot("BBB") == closes["BBB"].iloc[-1]


def test_compute_stats_recovers_parameters():
    md = compute_stats(synthetic_closes(n_days=5000, seed=1))
    np.testing.assert_allclose(md.vols, [0.2, 0.4], rtol=0.05)
    assert md.corr[0, 1] == pytest.approx(0.5, abs=0.05)


def test_ticker_order_respected():
    md = compute_stats(synthetic_closes(), ["BBB", "AAA"])
    assert md.tickers == ["BBB", "AAA"]
    assert md.vols[0] > md.vols[1]


def test_misaligned_dates_use_overlap_only():
    closes = synthetic_closes()
    closes.iloc[5, 0] = np.nan  # AAA missing one day
    md = compute_stats(closes)
    assert md.n_obs == len(closes) - 3  # the gap removes the two returns touching it
    assert np.all(np.isfinite(md.corr))


def test_missing_ticker_raises():
    with pytest.raises(ValueError, match="no price data"):
        compute_stats(synthetic_closes(), ["AAA", "ZZZ"])


def test_too_little_history_raises():
    with pytest.raises(ValueError, match="overlapping"):
        compute_stats(synthetic_closes(n_days=10))


def test_cache_roundtrip(tmp_path):
    calls = []

    def fake_download(tickers, period):
        calls.append(tuple(tickers))
        return synthetic_closes()

    a = load_closes(["AAA", "BBB"], cache_dir=tmp_path, downloader=fake_download)
    b = load_closes(["BBB", "AAA"], cache_dir=tmp_path, downloader=fake_download)  # order-insensitive key
    assert len(calls) == 1
    pd.testing.assert_frame_equal(a, b, check_freq=False)

    load_closes(["AAA", "BBB"], cache_dir=tmp_path, downloader=fake_download, refresh=True)
    assert len(calls) == 2


def test_stale_cache_used_when_download_fails(tmp_path):
    load_closes(["AAA", "BBB"], cache_dir=tmp_path, downloader=lambda t, p: synthetic_closes())

    def broken(tickers, period):
        raise ConnectionError("offline")

    md = get_market_data(["AAA", "BBB"], cache_dir=tmp_path, max_age_hours=0, downloader=broken)
    assert md.tickers == ["AAA", "BBB"]

    with pytest.raises(ConnectionError):
        get_market_data(["CCC"], cache_dir=tmp_path, downloader=broken)
