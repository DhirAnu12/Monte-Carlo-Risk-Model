"""End-to-end CLI tests with synthetic market data and option chains (no network)."""

from pathlib import Path

import numpy as np
import pandas as pd
import pytest

import implied_vol
import main
from market_data import compute_stats
from portfolio import load_positions

ROOT = Path(__file__).parent.parent


def fake_market_data(tickers, **kwargs):
    rng = np.random.default_rng(0)
    idx = pd.bdate_range(end="2026-11-11", periods=253)
    spots = {"AAPL": 355.0, "MSFT": 520.0, "SPY": 760.0}
    rets = rng.normal(0, 0.015, (252, len(tickers)))
    px = np.array([spots.get(t, 100.0) for t in tickers]) * np.exp(np.vstack([np.zeros(len(tickers)), rets.cumsum(0)]))
    px = px / px[-1] * np.array([spots.get(t, 100.0) for t in tickers])  # end exactly at spot
    return compute_stats(pd.DataFrame(px, index=idx, columns=list(tickers)), tickers)


def fake_chain_downloader(ticker, expiry):
    """A healthy quote (IV 0.31) for every sample contract, except the SPY put,
    whose quote is dead (no bid/ask, placeholder IV) to trigger the fallback."""
    rows = []
    for p in load_positions(ROOT / "positions.csv"):
        if p.ticker == ticker and p.expiry == expiry:
            dead = p.ticker == "SPY"
            rows.append((p.option_type, p.strike, 0.0 if dead else 1.0, 0.0 if dead else 1.1,
                         0.00001 if dead else 0.31))
    if not rows:
        raise implied_vol.ExpiryNotListed(f"{ticker} has no listed options expiring {expiry}")
    return pd.DataFrame(rows, columns=["type", "strike", "bid", "ask", "impliedVolatility"])


@pytest.fixture(autouse=True)
def offline(monkeypatch):
    monkeypatch.setattr(main, "get_market_data", fake_market_data)
    monkeypatch.setattr(implied_vol, "_yfinance_chain", fake_chain_downloader)


def run(tmp_path, *extra, positions=ROOT / "positions.csv"):
    return main.main(["--positions", str(positions), "--paths", "2000", "--horizon", "10",
                      "--cache-dir", str(tmp_path / "cache"), "--no-plots", *extra])


def test_cli_end_to_end(tmp_path, capsys):
    rc = main.main(["--positions", str(ROOT / "positions.csv"), "--paths", "2000", "--horizon", "10",
                    "--drift", "AAPL=0.1", "--cache-dir", str(tmp_path / "cache"), "--out", str(tmp_path)])
    assert rc == 0
    out = capsys.readouterr().out
    for s in ("VaR 95%", "CVaR 99%", "P(profit)", "TOTAL", "Long 10 AAPL 370C"):
        assert s in out
    assert (tmp_path / "pnl_histogram.png").stat().st_size > 10_000
    assert (tmp_path / "fan_chart.png").stat().st_size > 10_000


def test_cli_shows_both_vols_and_warns_on_fallback(tmp_path, capsys):
    assert run(tmp_path) == 0
    captured = capsys.readouterr()
    assert "Hist vol" in captured.out and "Impl vol" in captured.out
    aapl_row = next(l for l in captured.out.splitlines() if l.startswith("Long 10 AAPL 370C"))
    assert "31.0%" in aapl_row and "implied" in aapl_row
    spy_row = next(l for l in captured.out.splitlines() if l.startswith("Long 4 SPY 720P"))
    assert "historical" in spy_row
    # exactly one warning, naming the SPY position and the reason
    warnings = [l for l in captured.err.splitlines() if l.startswith("warning:")]
    assert len(warnings) == 1
    assert "Long 4 SPY 720P 2026-12-18" in warnings[0]
    assert "effectively zero" in warnings[0] and "historical vol" in warnings[0]


def test_cli_iv_override_column(tmp_path, capsys):
    csv = (ROOT / "positions.csv").read_text().splitlines()
    rows = [csv[0] if csv[0].endswith(",iv") else csv[0] + ",iv"]
    for line in csv[1:]:
        base = line.rstrip(",") if line.count(",") > 5 else line
        rows.append(base + (",0.55" if base.startswith("SPY") else ","))
    pos = tmp_path / "pos.csv"
    pos.write_text("\n".join(rows) + "\n")

    assert run(tmp_path, positions=pos) == 0
    captured = capsys.readouterr()
    spy_row = next(l for l in captured.out.splitlines() if l.startswith("Long 4 SPY 720P"))
    assert "55.0%" in spy_row and "iv override" in spy_row
    assert "warning:" not in captured.err  # override replaced the broken quote


def test_cli_no_iv_flag(tmp_path, capsys, monkeypatch):
    def boom(*a):
        raise AssertionError("chain should not be downloaded with --no-iv")

    monkeypatch.setattr(implied_vol, "_yfinance_chain", boom)
    assert run(tmp_path, "--no-iv") == 0
    captured = capsys.readouterr()
    assert "warning:" not in captured.err
    assert "implied " not in captured.out


def test_cli_rejects_unknown_drift_ticker(capsys):
    assert main.main(["--positions", str(ROOT / "positions.csv"), "--drift", "TSLA=0.2", "--no-plots"]) == 2
    assert "TSLA" in capsys.readouterr().err


def test_cli_bad_positions_file(tmp_path, capsys):
    bad = tmp_path / "bad.csv"
    bad.write_text("ticker,type\nAAPL,call\n")
    assert main.main(["--positions", str(bad), "--no-plots"]) == 2


def test_parse_drift():
    assert main.parse_drift(["aapl=0.1", "SPY=-0.05"]) == {"AAPL": 0.1, "SPY": -0.05}
