"""Command-line entry point: run the full Monte Carlo risk model on a positions file.

Example
-------
    python main.py --positions positions.csv --paths 10000 --horizon 21 \
        --rate 0.04 --seed 42 --drift AAPL=0.10 --out output
"""

from __future__ import annotations

import argparse
import logging
import sys
from datetime import date
from pathlib import Path

from implied_vol import VolChoice, resolve_pricing_vols
from market_data import DEFAULT_CACHE_DIR, get_market_data
from plots import fan_chart, pnl_histogram
from portfolio import PortfolioError, load_positions, tickers_of
from risk import RiskMetrics, RiskReport, run_risk
from simulate import simulate_gbm


def parse_drift(items: list[str]) -> dict[str, float]:
    """Parse repeated --drift TICKER=MU arguments into a dict."""
    out: dict[str, float] = {}
    for item in items:
        try:
            k, v = item.split("=", 1)
            out[k.strip().upper()] = float(v)
        except ValueError:
            raise argparse.ArgumentTypeError(f"--drift expects TICKER=VALUE, got {item!r}")
    return out


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description="Monte Carlo risk model for an options portfolio.")
    p.add_argument("--positions", default="positions.csv", help="positions CSV (default: positions.csv)")
    p.add_argument("--paths", type=int, default=10_000, help="number of simulated paths (default: 10000)")
    p.add_argument("--horizon", type=int, default=21, help="horizon in trading days (default: 21 ≈ 1 month)")
    p.add_argument("--rate", type=float, default=0.04, help="risk-free rate, annual, continuous (default: 0.04)")
    p.add_argument("--drift", action="append", default=[], metavar="TICKER=MU",
                   help="annual drift override for one ticker; repeatable (default drift = --rate)")
    p.add_argument("--seed", type=int, default=42, help="random seed (default: 42)")
    p.add_argument("--period", default="1y", help="history used for vol/correlation (default: 1y)")
    p.add_argument("--valuation-date", type=date.fromisoformat, default=None,
                   help="YYYY-MM-DD; default = date of the latest close")
    p.add_argument("--refresh", action="store_true", help="ignore cached prices/option chains and re-download")
    p.add_argument("--no-iv", action="store_true",
                   help="price options at historical vol instead of market implied vol (iv overrides still apply)")
    p.add_argument("--cache-dir", type=Path, default=DEFAULT_CACHE_DIR, help="where downloaded data is cached")
    p.add_argument("--out", default="output", help="directory for charts (default: output)")
    p.add_argument("--no-plots", action="store_true", help="skip chart generation")
    return p


# --- Formatting --------------------------------------------------------------

def money(x: float) -> str:
    return f"-${abs(x):,.0f}" if x < 0 else f"${x:,.0f}"


def table(headers: list[str], rows: list[list[str]], align: str) -> str:
    """Plain-text table. `align` has one char per column: 'l' or 'r'."""
    widths = [max(len(h), *(len(r[i]) for r in rows)) for i, h in enumerate(headers)]
    fmt = lambda cells: "  ".join(c.ljust(w) if a == "l" else c.rjust(w) for c, w, a in zip(cells, widths, align))
    return "\n".join([fmt(headers), "  ".join("-" * w for w in widths), *(fmt(r) for r in rows)])


def metrics_rows(m: RiskMetrics) -> list[tuple[str, str]]:
    return [
        ("Mean P&L", money(m.mean)),
        ("Median P&L", money(m.median)),
        ("Std dev", money(m.std)),
        ("P(profit)", f"{m.prob_profit:.1%}"),
        ("VaR 95%", money(m.var_95)),
        ("CVaR 95%", money(m.cvar_95)),
        ("VaR 99%", money(m.var_99)),
        ("CVaR 99%", money(m.cvar_99)),
        ("Max loss", money(m.max_loss)),
        ("Max gain", money(m.max_gain)),
    ]


def print_report(rep: RiskReport, md, args, drift: dict[str, float], choices: list[VolChoice]) -> None:
    print(f"\nValuation date {rep.valuation_date}  →  horizon {rep.horizon_date} "
          f"({args.horizon} trading days)  ·  {args.paths:,} paths  ·  seed {args.seed}  ·  r = {args.rate:.2%}")

    print("\nMarket data (" + f"{md.n_obs} daily returns, last close {md.as_of.date()})")
    rows = [[t, f"${md.spots[i]:,.2f}", f"{md.vols[i]:.1%}", f"{drift.get(t, args.rate):.2%}",
             *(f"{md.corr[i, j]:+.2f}" for j in range(len(md.tickers)))] for i, t in enumerate(md.tickers)]
    print(table(["Ticker", "Spot", "Vol", "Drift", *md.tickers], rows, "lrrr" + "r" * len(md.tickers)))

    print("\nPositions (today, Black-Scholes; Greeks in $ for the whole position)")
    rows = []
    for j, (s, c) in enumerate(zip(rep.snapshots, choices)):
        p = s.position
        expired = p.expiry <= rep.horizon_date
        iv = "n/a" if c.implied_vol is None else f"{c.implied_vol:.1%}"
        rows.append([
            p.label(), f"{c.hist_vol:.1%}", iv, VOL_SOURCE_LABEL[c.source],
            f"{p.entry_price:.2f}", f"{s.unit_value:.2f}", money(s.unrealized_pnl),
            money(s.delta), f"{s.gamma:+.1f}", money(s.vega), money(s.theta),
            money(rep.position_pnl[:, j].mean()), "yes" if expired else "",
        ])
    tot = lambda f: sum(getattr(s, f) for s in rep.snapshots)
    rows.append(["TOTAL", "", "", "", "", "", money(tot("unrealized_pnl")), money(tot("delta")), f"{tot('gamma'):+.1f}",
                 money(tot("vega")), money(tot("theta")), money(rep.pnl.mean()), ""])
    print(table(["Position", "Hist vol", "Impl vol", "Priced at", "Entry", "Value", "Unreal. P&L",
                 "Delta $/1", "Gamma", "Vega /1%", "Theta /day", "E[P&L] @H", "Exp. by H"],
                rows, "lrrlrrrrrrrrl"))
    print("Paths are simulated with historical vol and correlation; options are priced at the 'Priced at' vol.")

    print("\nP&L distribution at horizon")
    a, b = metrics_rows(rep.metrics), metrics_rows(rep.metrics_from_today)
    print(table(["Metric", "vs. entry price", "vs. today's value"],
                [[k, v1, v2] for (k, v1), (_, v2) in zip(a, b)], "lrr"))
    print("VaR/CVaR are losses (positive = money lost). 'vs. today' isolates risk from now to the horizon.")


VOL_SOURCE_LABEL = {"chain": "implied", "override": "iv override", "historical": "historical"}


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    logging.basicConfig(level=logging.WARNING, format="%(levelname)s: %(message)s")

    try:
        positions = load_positions(args.positions)
        drift = parse_drift(args.drift)
    except (PortfolioError, argparse.ArgumentTypeError, FileNotFoundError) as e:
        print(f"error: {e}", file=sys.stderr)
        return 2

    tickers = tickers_of(positions)
    unknown = set(drift) - set(tickers)
    if unknown:
        print(f"error: --drift given for tickers not in portfolio: {sorted(unknown)}", file=sys.stderr)
        return 2

    md = get_market_data(tickers, period=args.period, cache_dir=args.cache_dir, refresh=args.refresh)
    valuation_date = args.valuation_date or md.as_of.date()
    already_expired = [p.label() for p in positions if p.expiry < valuation_date]
    if already_expired:
        print(f"warning: positions expired before valuation date: {already_expired}", file=sys.stderr)

    sim = simulate_gbm(md.tickers, md.spots, md.vols, md.corr, horizon_days=args.horizon,
                       n_paths=args.paths, rate=args.rate, drift=drift, seed=args.seed)
    vols = {t: md.vol(t) for t in md.tickers}
    choices = resolve_pricing_vols(positions, vols, valuation_date, use_market_iv=not args.no_iv,
                                   cache_dir=args.cache_dir, refresh=args.refresh)
    for c in choices:
        if c.warning:
            print(f"warning: {c.position.label()}: {c.warning}; "
                  f"falling back to historical vol {c.hist_vol:.1%}", file=sys.stderr)

    rep = run_risk(positions, sim, vols, args.rate, valuation_date,
                   pricing_vols=[c.pricing_vol for c in choices])

    print_report(rep, md, args, drift, choices)

    if not args.no_plots:
        out = Path(args.out)
        out.mkdir(parents=True, exist_ok=True)
        h = pnl_histogram(rep.pnl, rep.metrics, out / "pnl_histogram.png",
                          f"Portfolio P&L at {rep.horizon_date} vs. entry price")
        f = fan_chart(sim, positions, out / "fan_chart.png",
                      f"Simulated price paths, {args.horizon} trading days")
        print(f"\nSaved {h}\nSaved {f}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
